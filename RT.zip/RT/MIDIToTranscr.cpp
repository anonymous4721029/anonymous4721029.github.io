#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include "Transcr_v160315.hpp"
#include "PianoRoll_v160425.hpp"
using namespace std;

int main(int argc,char** argv){

	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=3){cout<<"Error in usage! : $./MIDIToTranscr in.mid out_transcr.txt"<<endl; return -1;}

	PianoRoll pr;
	Transcr transcr;

	pr.ReadMIDIFile(string(argv[1]));

	transcr.TPQN=24;
	transcr.logP=0;
	TranscrEvt evt;
	double lastOfftime=0;
	for(int n=0;n<pr.prEvts.size();n+=1){
		if(pr.prEvts[n].offtime>lastOfftime){lastOfftime=pr.prEvts[n].offtime;}

		evt.ID=n;
		evt.ontime=pr.prEvts[n].ontime;
		evt.offtime=pr.prEvts[n].offtime;
		evt.sitch=pr.prEvts[n].sitch;
		evt.onvel=pr.prEvts[n].onvel;
		evt.offvel=pr.prEvts[n].offvel;
		evt.chan=pr.prEvts[n].channel;
		evt.stime=-1;
		evt.dur=-1;
		transcr.evts.push_back(evt);
	}//endfor n

	evt.ID=-1;
	evt.ontime=lastOfftime;
	evt.stime=-1;
	transcr.evts.push_back(evt);

	transcr.WriteFile(string(argv[2]));

	return 0;

}//end main
