#ifndef NOTEHMM_HPP
#define NOTEHMM_HPP

#define printOn false

#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include <vector>
#include <fstream>
#include <cassert>
#include <algorithm>
#include "Transcr_v160315.hpp"
using namespace std;

inline double LogAdd(double d1,double d2){
	//log(exp(d1)+exp(d2))=log(exp(d1)(1+exp(d2-d1)))
	if(d1>d2){return d1+log(1+exp(d2-d1));
	}else{return d2+log(1+exp(d1-d2));
	}//endif
}//end LogAdd
inline void norm(vector<double>& vd){
	double sum=0;
	for(int i=0;i<vd.size();i+=1){sum+=vd[i];if(vd[i]<0){cout<<"negative weight!"<<endl;}}
	for(int i=0;i<vd.size();i+=1){vd[i]/=sum;}
	return;
}//
inline void lognorm(vector<double>& vd){
	double tmpd=vd[0];
	for(int i=0;i<vd.size();i+=1){if(vd[i]>tmpd){tmpd=vd[i];}}//endfor i
	for(int i=0;i<vd.size();i+=1){vd[i]-=tmpd;}//endfor i
	tmpd=0;
	for(int i=0;i<vd.size();i+=1){tmpd+=exp(vd[i]);}//endfor i
	tmpd=log(tmpd);
	for(int i=0;i<vd.size();i+=1){vd[i]-=tmpd;if(vd[i]<-200){vd[i]=-200;}}//endfor i
}//

class Prob{
public:
	vector<double> P;
	vector<double> LP;

	void Normalize(){
		norm(P);
		PToLP();
	}//end Normalize

	void PToLP(){
		LP.clear();
		LP.resize(P.size());
		for(int i=0;i<P.size();i+=1){
			LP[i]=log(P[i]);
		}//endfor i
	}//end PToLP

	void LPToP(){
		P.clear();
		P.resize(LP.size());
		for(int i=0;i<LP.size();i+=1){
			P[i]=exp(LP[i]);
		}//endfor i
	}//end LPToP

	string Print(){
		stringstream ss;
		ss.str("");
		for(int i=0;i<P.size();i+=1){
			ss<<P[i]<<" ";
		}//endfor i
		return ss.str();
	}//end Print

};//endclass Prob

class NoteHMM{
public:
	int TPQN;
	Transcr data;

	vector<int> nv;
	int numNoteValue;
	vector<Prob> trProb;
	Prob trIniProb;
	vector<Prob> stateInProb;//stateInProb[r].P[0]=a^r_in,s
	vector<Prob> stateStayProb;//stateStayProb[r].P[0]=a^r_s,s

	double sigma_t;//オンセット時刻のノイズの分散
	double lambda;//chordal IOIの指数分布のscale parameter
	double fac_lambda,fac_t;
	vector<double> secPerQN;
	vector<Prob> tempoTrProb;
	Prob tempoTrIniProb;
	int numTempoState;
	double minSecPerQN,maxSeqPerQN;
	int truncatedWidth;
	double outerLP;

	NoteHMM(){
		Init();
	}//end NoteHMM
	~NoteHMM(){}//end ~NoteHMM

	void Init(){
if(printOn){cout<<"###Init###"<<endl;}

		TPQN=24;

		int nvList[]={96,72,64,48,36,32,24,18,16,12,9,8,6,4,3};
		numNoteValue=15;
		nv.clear();
		for(int i=0;i<numNoteValue;i+=1){
			nv.push_back(nvList[i]);
		}//endfor i

//Set note-value probabilities
		trProb.resize(numNoteValue);
		stateInProb.resize(numNoteValue);
		stateStayProb.resize(numNoteValue);
		for(int i=0;i<numNoteValue;i+=1){
			trProb[i].P.resize(numNoteValue);
			stateInProb[i].P.resize(2);
			stateStayProb[i].P.resize(2);
		}//endfor i
		trIniProb.P.resize(numNoteValue);

		stateInProb[0].P[0]=0.772156;	stateStayProb[0].P[0]=0.82612;
		stateInProb[1].P[0]=0.876323;	stateStayProb[1].P[0]=0.801412;
		stateInProb[2].P[0]=0.989899;	stateStayProb[2].P[0]=0.980583;
		stateInProb[3].P[0]=0.898658;	stateStayProb[3].P[0]=0.799889;
		stateInProb[4].P[0]=0.891985;	stateStayProb[4].P[0]=0.797928;
		stateInProb[5].P[0]=0.989899;	stateStayProb[5].P[0]=0.980583;
		stateInProb[6].P[0]=0.74746;	stateStayProb[6].P[0]=0.769629;
		stateInProb[7].P[0]=0.783911;	stateStayProb[7].P[0]=0.786074;
		stateInProb[8].P[0]=0.355793;	stateStayProb[8].P[0]=0.792661;
		stateInProb[9].P[0]=0.560302;	stateStayProb[9].P[0]=0.737182;
		stateInProb[10].P[0]=0.564169;	stateStayProb[10].P[0]=0.786676;
		stateInProb[11].P[0]=0.305673;	stateStayProb[11].P[0]=0.719369;
		stateInProb[12].P[0]=0.425348;	stateStayProb[12].P[0]=0.719093;
		stateInProb[13].P[0]=0.273423;	stateStayProb[13].P[0]=0.717485;
		stateInProb[14].P[0]=0.304418;	stateStayProb[14].P[0]=0.723008;
		trProb[0].P[0]=0.503665;	trProb[0].P[1]=0.0534031;	trProb[0].P[2]=0.00104712;	trProb[0].P[3]=0.0743455;	trProb[0].P[4]=0.00104712;	trProb[0].P[5]=0.00104712;	trProb[0].P[6]=0.137173;	trProb[0].P[7]=0.0324607;	trProb[0].P[8]=0.00104712;	trProb[0].P[9]=0.126702;	trProb[0].P[10]=0.00104712;	trProb[0].P[11]=0.0534031;	trProb[0].P[12]=0.0115183;	trProb[0].P[13]=0.00104712;	trProb[0].P[14]=0.00104712;	
		trProb[1].P[0]=0.000400802;	trProb[1].P[1]=0.248898;	trProb[1].P[2]=0.000400802;	trProb[1].P[3]=0.120641;	trProb[1].P[4]=0.044489;	trProb[1].P[5]=0.000400802;	trProb[1].P[6]=0.333066;	trProb[1].P[7]=0.00841683;	trProb[1].P[8]=0.000400802;	trProb[1].P[9]=0.160721;	trProb[1].P[10]=0.00440882;	trProb[1].P[11]=0.052505;	trProb[1].P[12]=0.0244489;	trProb[1].P[13]=0.000400802;	trProb[1].P[14]=0.000400802;	
		trProb[2].P[0]=0.0666667;	trProb[2].P[1]=0.0666667;	trProb[2].P[2]=0.0666667;	trProb[2].P[3]=0.0666667;	trProb[2].P[4]=0.0666667;	trProb[2].P[5]=0.0666667;	trProb[2].P[6]=0.0666667;	trProb[2].P[7]=0.0666667;	trProb[2].P[8]=0.0666667;	trProb[2].P[9]=0.0666667;	trProb[2].P[10]=0.0666667;	trProb[2].P[11]=0.0666667;	trProb[2].P[12]=0.0666667;	trProb[2].P[13]=0.0666667;	trProb[2].P[14]=0.0666667;	
		trProb[3].P[0]=0.00863079;	trProb[3].P[1]=0.0224827;	trProb[3].P[2]=0.000106553;	trProb[3].P[3]=0.16846;	trProb[3].P[4]=0.0416622;	trProb[3].P[5]=0.000106553;	trProb[3].P[6]=0.472136;	trProb[3].P[7]=0.0437933;	trProb[3].P[8]=0.000106553;	trProb[3].P[9]=0.174853;	trProb[3].P[10]=0.00117208;	trProb[3].P[11]=0.0107619;	trProb[3].P[12]=0.0469899;	trProb[3].P[13]=0.00436867;	trProb[3].P[14]=0.00436867;	
		trProb[4].P[0]=0.00208024;	trProb[4].P[1]=0.0119861;	trProb[4].P[2]=9.90589e-05;	trProb[4].P[3]=0.00703318;	trProb[4].P[4]=0.268549;	trProb[4].P[5]=9.90589e-05;	trProb[4].P[6]=0.0615156;	trProb[4].P[7]=0.0109955;	trProb[4].P[8]=9.90589e-05;	trProb[4].P[9]=0.466667;	trProb[4].P[10]=0.00406142;	trProb[4].P[11]=9.90589e-05;	trProb[4].P[12]=0.115998;	trProb[4].P[13]=0.0357603;	trProb[4].P[14]=0.0149579;	
		trProb[5].P[0]=0.0666667;	trProb[5].P[1]=0.0666667;	trProb[5].P[2]=0.0666667;	trProb[5].P[3]=0.0666667;	trProb[5].P[4]=0.0666667;	trProb[5].P[5]=0.0666667;	trProb[5].P[6]=0.0666667;	trProb[5].P[7]=0.0666667;	trProb[5].P[8]=0.0666667;	trProb[5].P[9]=0.0666667;	trProb[5].P[10]=0.0666667;	trProb[5].P[11]=0.0666667;	trProb[5].P[12]=0.0666667;	trProb[5].P[13]=0.0666667;	trProb[5].P[14]=0.0666667;	
		trProb[6].P[0]=0.00141881;	trProb[6].P[1]=0.0076757;	trProb[6].P[2]=8.81251e-06;	trProb[6].P[3]=0.0408108;	trProb[6].P[4]=0.0161357;	trProb[6].P[5]=8.81251e-06;	trProb[6].P[6]=0.642265;	trProb[6].P[7]=0.0260057;	trProb[6].P[8]=8.81251e-06;	trProb[6].P[9]=0.209042;	trProb[6].P[10]=0.00194757;	trProb[6].P[11]=0.0087332;	trProb[6].P[12]=0.0371095;	trProb[6].P[13]=0.00291694;	trProb[6].P[14]=0.0059132;	
		trProb[7].P[0]=7.18133e-05;	trProb[7].P[1]=7.18133e-05;	trProb[7].P[2]=7.18133e-05;	trProb[7].P[3]=7.18133e-05;	trProb[7].P[4]=0.00294434;	trProb[7].P[5]=7.18133e-05;	trProb[7].P[6]=0.0151526;	trProb[7].P[7]=0.0374147;	trProb[7].P[8]=7.18133e-05;	trProb[7].P[9]=0.0137163;	trProb[7].P[10]=7.18133e-05;	trProb[7].P[11]=7.18133e-05;	trProb[7].P[12]=0.872603;	trProb[7].P[13]=7.18133e-05;	trProb[7].P[14]=0.0575224;	
		trProb[8].P[0]=0.000843882;	trProb[8].P[1]=0.000843882;	trProb[8].P[2]=0.000843882;	trProb[8].P[3]=0.000843882;	trProb[8].P[4]=0.000843882;	trProb[8].P[5]=0.000843882;	trProb[8].P[6]=0.000843882;	trProb[8].P[7]=0.000843882;	trProb[8].P[8]=0.912236;	trProb[8].P[9]=0.0177215;	trProb[8].P[10]=0.000843882;	trProb[8].P[11]=0.0514768;	trProb[8].P[12]=0.000843882;	trProb[8].P[13]=0.0092827;	trProb[8].P[14]=0.000843882;	
		trProb[9].P[0]=0.00036364;	trProb[9].P[1]=0.00121426;	trProb[9].P[2]=2.12655e-06;	trProb[9].P[3]=0.00338334;	trProb[9].P[4]=0.00765771;	trProb[9].P[5]=2.12655e-06;	trProb[9].P[6]=0.0503801;	trProb[9].P[7]=0.00525471;	trProb[9].P[8]=4.46576e-05;	trProb[9].P[9]=0.870718;	trProb[9].P[10]=0.00221374;	trProb[9].P[11]=0.00078895;	trProb[9].P[12]=0.0491467;	trProb[9].P[13]=0.00444662;	trProb[9].P[14]=0.00438282;	
		trProb[10].P[0]=0.000187441;	trProb[10].P[1]=0.000187441;	trProb[10].P[2]=0.000187441;	trProb[10].P[3]=0.000187441;	trProb[10].P[4]=0.00206186;	trProb[10].P[5]=0.000187441;	trProb[10].P[6]=0.00206186;	trProb[10].P[7]=0.00393627;	trProb[10].P[8]=0.000187441;	trProb[10].P[9]=0.0226804;	trProb[10].P[10]=0.182006;	trProb[10].P[11]=0.00206186;	trProb[10].P[12]=0.0133083;	trProb[10].P[13]=0.000187441;	trProb[10].P[14]=0.770572;	
		trProb[11].P[0]=0.000611328;	trProb[11].P[1]=0.000131855;	trProb[11].P[2]=1.19868e-05;	trProb[11].P[3]=0.0014504;	trProb[11].P[4]=1.19868e-05;	trProb[11].P[5]=1.19868e-05;	trProb[11].P[6]=0.0125981;	trProb[11].P[7]=1.19868e-05;	trProb[11].P[8]=0.000851064;	trProb[11].P[9]=0.00396764;	trProb[11].P[10]=1.19868e-05;	trProb[11].P[11]=0.949488;	trProb[11].P[12]=0.00324843;	trProb[11].P[13]=0.0275817;	trProb[11].P[14]=1.19868e-05;	
		trProb[12].P[0]=4.14419e-05;	trProb[12].P[1]=0.000121652;	trProb[12].P[2]=1.33684e-06;	trProb[12].P[3]=0.00145849;	trProb[12].P[4]=0.00152533;	trProb[12].P[5]=1.33684e-06;	trProb[12].P[6]=0.0113243;	trProb[12].P[7]=0.00846351;	trProb[12].P[8]=1.33684e-06;	trProb[12].P[9]=0.0307619;	trProb[12].P[10]=0.000415756;	trProb[12].P[11]=0.000990595;	trProb[12].P[12]=0.92953;	trProb[12].P[13]=0.00144512;	trProb[12].P[14]=0.0139178;	
		trProb[13].P[0]=1.61538e-05;	trProb[13].P[1]=0.000339229;	trProb[13].P[2]=1.61538e-05;	trProb[13].P[3]=0.000985381;	trProb[13].P[4]=0.00260076;	trProb[13].P[5]=1.61538e-05;	trProb[13].P[6]=0.0121315;	trProb[13].P[7]=0.00211615;	trProb[13].P[8]=1.61538e-05;	trProb[13].P[9]=0.0320006;	trProb[13].P[10]=0.00163153;	trProb[13].P[11]=0.0320006;	trProb[13].P[12]=0.0126161;	trProb[13].P[13]=0.898651;	trProb[13].P[14]=0.00486229;	
		trProb[14].P[0]=6.1529e-06;	trProb[14].P[1]=6.76819e-05;	trProb[14].P[2]=6.1529e-06;	trProb[14].P[3]=0.000436856;	trProb[14].P[4]=0.00111367;	trProb[14].P[5]=6.1529e-06;	trProb[14].P[6]=0.00671281;	trProb[14].P[7]=0.00425165;	trProb[14].P[8]=6.1529e-06;	trProb[14].P[9]=0.027202;	trProb[14].P[10]=0.0151423;	trProb[14].P[11]=0.000436856;	trProb[14].P[12]=0.0567359;	trProb[14].P[13]=0.00431318;	trProb[14].P[14]=0.883563;	
		trIniProb.P[0]=0.000649545;	trIniProb.P[1]=0.00158997;	trIniProb.P[2]=9.4065e-06;	trIniProb.P[3]=0.00583544;	trIniProb.P[4]=0.00612119;	trIniProb.P[5]=9.4065e-06;	trIniProb.P[6]=0.0691682;	trIniProb.P[7]=0.0080631;	trIniProb.P[8]=0.000834508;	trIniProb.P[9]=0.279934;	trIniProb.P[10]=0.00297868;	trIniProb.P[11]=0.0596259;	trIniProb.P[12]=0.42993;	trIniProb.P[13]=0.0434327;	trIniProb.P[14]=0.0918171;	

		for(int i=0;i<numNoteValue;i+=1){
			stateInProb[i].P[1]=1-stateInProb[i].P[0];
			stateStayProb[i].P[1]=1-stateStayProb[i].P[0];
		}//endfor i

		for(int i=0;i<numNoteValue;i+=1){
			trProb[i].Normalize();
			stateInProb[i].Normalize();
			stateStayProb[i].Normalize();
		}//endfor i
		trIniProb.Normalize();

//////Init tempo model
		sigma_t=0.02;
		lambda=0.0101;
		minSecPerQN=0.3;//BPM=200
		maxSeqPerQN=1.5;//BPM=40
		numTempoState=50;
		truncatedWidth=6;
		double SigmaV=1.;
		fac_t=-0.5*log(2*M_PI*sigma_t*sigma_t);
		fac_lambda=-log(lambda);

		double eps=log(maxSeqPerQN/minSecPerQN)/numTempoState;
		for(int i=0;i<numTempoState;i+=1){
			secPerQN.push_back(minSecPerQN*exp(i*eps));
		}//endfor i

		tempoTrProb.resize(numTempoState);
		for(int i=0;i<numTempoState;i+=1){
			tempoTrProb[i].P.resize(numTempoState);
			for(int j=0;j<numTempoState;j+=1){
				tempoTrProb[i].P[j]=exp(-0.5*pow((i-j)/SigmaV,2.));
			}//endfor j
			tempoTrProb[i].Normalize();
		}//endfor i

		tempoTrIniProb.P.resize(numTempoState);
		for(int i=0;i<numTempoState;i+=1){
			tempoTrIniProb.P[i]=exp(-0.5*pow((i-numTempoState/2)/(3*SigmaV),2.));
		}//endfor i
		tempoTrIniProb.Normalize();

if(printOn){cout<<"###Init END###"<<endl;}
	}//end Init


	void ReadData_Transcr(string filename){
		data.ReadFile(filename);
		data.TPQN=24;
		for(int n=0;n<data.evts.size();n+=1){data.evts[n].chan=0;}
	}//end ReadData_Transcr

	double OutputLP(int nvID,int tempoID,double ioi){
		if(nvID%2==0){//short (chordal) IOI
			return fac_lambda-ioi/lambda;
		}else{//long (non-chordal) IOI
			return fac_t-0.5*pow((ioi-nv[nvID/2]*secPerQN[tempoID]/double(TPQN))/sigma_t,2.);
		}//endif
	}//end OutputLP

	void Viterbi(){
if(printOn){cout<<"###Viterbi###"<<endl;}
		int numNVState=numNoteValue*2;

		vector<double> iois;
		for(int n=1;n<data.evts.size();n+=1){
			iois.push_back(data.evts[n].ontime-data.evts[n-1].ontime);
		}//endfor n

		vector<vector<double> > LP;//LP[nvID][tempoID], nvID=iN=r*i=[0,...,numNoteValue]x[0,1], i=iN%2; r=iN/2;
		vector<vector<vector<vector<int> > > > amax;//amax[n][nvID][tempoID][0,1]=(nvID,tempoID)

		LP.resize(numNVState);
		for(int i=0;i<numNVState;i+=1){LP[i].resize(numTempoState);}
		amax.resize(iois.size());
		for(int n=0;n<iois.size();n+=1){
			amax[n].resize(numNVState);
			for(int i=0;i<numNVState;i+=1){
				amax[n][i].resize(numTempoState);
				for(int j=0;j<numTempoState;j+=1){
					amax[n][i][j].resize(2);
				}//endfor j
			}//endfor i
		}//endfor n

		int iN,jN,iN0,iNr,jNr,iNi;
//Set initial probability
		for(iN=0;iN<numNVState;iN+=1)for(int iT=0;iT<numTempoState;iT+=1){
			LP[iN][iT]=trIniProb.LP[iN/2]+stateInProb[iN/2].LP[iN%2]+tempoTrIniProb.LP[iT]+OutputLP(iN,iT,iois[0]);
		}//endfor iN,iT

//Forward path
		for(int n=1;n<iois.size();n+=1){
if(printOn){cout<<"Viterbi "<<n<<endl;}
			vector<vector<double> > preLP;//LP[nvID][tempoID]
			preLP=LP;
			double logP;
			for(iN=0;iN<numNVState;iN+=1)for(int iT=0;iT<numTempoState;iT+=1){//jN,jT->iN,iT
				iNr=iN/2;
				iNi=iN%2;
				iN0=iNr*2;
				LP[iN][iT]=preLP[iN0][iT]+trProb[iNr].LP[iNr]+tempoTrProb[iT].LP[iT];
				amax[n][iN][iT][0]=iN0; amax[n][iN][iT][1]=iT;

				for(jNr=0;jNr<numNoteValue;jNr+=1)for(int jT=0;jT<numTempoState;jT+=1){
					jN=jNr*2+1;
					logP=preLP[jN][jT]+trProb[jNr].LP[iNr]+stateInProb[iNr].LP[iNi]+tempoTrProb[jT].LP[iT];
					if(logP>LP[iN][iT]){
						LP[iN][iT]=logP;
						amax[n][iN][iT][0]=jN; amax[n][iN][iT][1]=jT;
					}//endif
				}//endfor jNr,jT

				for(int jT=0;jT<numTempoState;jT+=1){
					jN=iNr*2;
					logP=preLP[jN][jT]+stateStayProb[iNr].LP[iNi]+tempoTrProb[jT].LP[iT];
					if(logP>LP[iN][iT]){
						LP[iN][iT]=logP;
						amax[n][iN][iT][0]=jN; amax[n][iN][iT][1]=jT;
					}//endif
				}//endfor jT

				LP[iN][iT]+=OutputLP(iN,iT,iois[n]);

			}//endfor iN,iT
		}//endfor n

//Backtracking
		vector<vector<int> > optimalPath;//optimalPath[n][0,1,2]=nvID,tempoID,non-chordal(0)/chordal(1)
		optimalPath.resize(iois.size());
		for(int i=0;i<iois.size();i+=1){optimalPath[i].assign(2,0);}
		double max;
		max=LP[0][0];
		for(iN=0;iN<numNVState;iN+=1)for(int iT=0;iT<numTempoState;iT+=1){
			if(LP[iN][iT]>max){
				max=LP[iN][iT];
				optimalPath[iois.size()-1][0]=iN;
				optimalPath[iois.size()-1][1]=iT;
			}//endif
		}//endfor iN,iT
		data.logP=max;
		for(int n=iois.size()-2;n>=0;n-=1){
			optimalPath[n][0]=amax[n+1][optimalPath[n+1][0]][optimalPath[n+1][1]][0];
			optimalPath[n][1]=amax[n+1][optimalPath[n+1][0]][optimalPath[n+1][1]][1];
		}//endfor n

		data.evts[0].stime=0;
		for(int n=0;n<iois.size();n+=1){
			if(optimalPath[n][0]%2==0){//short IOI
				data.evts[n+1].stime=data.evts[n].stime;
			}else{//long IOI
				data.evts[n+1].stime=data.evts[n].stime+nv[optimalPath[n][0]/2];
			}//endif
			data.evts[n].dur=data.evts[n+1].stime-data.evts[n].stime;
		}//endfor n

if(printOn){cout<<"###Viterbi END###"<<endl;}
	}//end Viterbi

	void Print(){
		TPQN=24;
		for(int n=0;n<data.evts.size();n+=1){
			TranscrEvt evt=data.evts[n];
cout<<evt.ontime<<"\t"<<evt.sitch<<"\t"<<evt.stime<<"\t"<<evt.dur<<endl;
		}//endfor n
	}//end Print

	void WriteFile(string filename){
		data.WriteFile(filename);
	}//end WriteFile

};//endclass NoteHMM


#endif // NOTEHMM_HPP

