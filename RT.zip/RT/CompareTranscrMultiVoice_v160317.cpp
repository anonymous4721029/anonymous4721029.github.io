#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
using namespace std;

int gcd(int m,int n){
  if(0==m||0==n){return 0;}
  while(m!=n){if(m>n){m=m-n;}else{n=n-m;}}//endwhile
  return m;
}//end gcd

int lcm(int m,int n){
  if(0==m||0==n){return 0;}
  return ((m/gcd(m,n))*n);//lcm=m*n/gcd(m,n)
}//end lcm

class IrredFrac{
public:
  int num;
  int den;

  IrredFrac(){};//end IrredFrac
  IrredFrac(int num_,int den_){
    int sign=1;
    assert(den_!=0);
    if(num_==0){
      num=num_;
      den=1;
    }else{
      if(den_<0){
        sign*=-1;
        den_*=-1;
      }//endif
      if(num_<0){
        sign*=-1;
        num_*=-1;
      }//endif
      int fac=gcd(num_,den_);
      num=sign*(num_/fac);
      den=den_/fac;
    }//end
  }//end IrredFrac
  ~IrredFrac(){}//end ~IrredFrac

  string Show(){
    stringstream ss;
    ss.str("");
    ss<<num<<"/"<<den;
    return ss.str();
  }//end Show

};//end class IrredFrac

  IrredFrac AddIrredFrac(IrredFrac irf1,IrredFrac irf2){
    return IrredFrac(irf2.den*irf1.num+irf1.den*irf2.num,irf1.den*irf2.den);
  }//end AddIrredFrac

  IrredFrac MultIrredFrac(IrredFrac irf1,IrredFrac irf2){
    return IrredFrac(irf1.num*irf2.num,irf1.den*irf2.den);
  }//end MultIrredFrac

  IrredFrac MinusIrredFrac(IrredFrac irf1){
    return IrredFrac(-1*irf1.num,irf1.den);
  }//end MinusIrredFrac

  IrredFrac InvIrredFrac(IrredFrac irf1){
    return IrredFrac(irf1.den,irf1.num);
  }//end InvIrredFrac

  IrredFrac SubtrIrredFrac(IrredFrac irf1,IrredFrac irf2){
    return AddIrredFrac(irf1,MinusIrredFrac(irf2));
  }//end SubtrIrredFrac

class TranscrEvt{
public:
  int ID;
  double ontime;
  double offtime;
  string sitch;
  int onvel;
  int offvel;
  int chan;
  int stime;
  int dur;
  IrredFrac normStime;
};//end class TranscrEvt

class Transcr{
public:
  int TPQN;
  vector<string> comments;
  vector<TranscrEvt> evts;

  void ReadFile(string filename){
    comments.clear();
    evts.clear();
    vector<int> v(100);
    vector<double> d(100);
    vector<string> s(100);
    TranscrEvt evt;
    ifstream ifs(filename.c_str());
    while(ifs>>s[0]){
      if(s[0][0]=='/' || s[0][0]=='#'){
        getline(ifs,s[99]);
        istringstream iss(s[99]);
        iss>>s[98];
        if(s[98]=="TPQN:"){iss>>TPQN;}
        comments.push_back(s[99]);
        continue;
      }//endif

      if(s[0]=="end"){
        evt.chan = 0;
        ifs>>evt.ontime>>evt.stime>>evt.chan;
        evt.offtime = -1;
        evt.sitch   = "NA";
        evt.onvel   = -1;
        evt.offvel  = -1;
        evt.dur     = 0;
        evts.push_back(evt);
        getline(ifs,s[99]);
        continue;
      }//endif

      evt.ID      = atoi(s[0].c_str());
      ifs>>evt.ontime>>evt.offtime>>evt.sitch>>evt.onvel>>evt.offvel>>evt.chan>>evt.stime>>evt.dur;
      evts.push_back(evt);

      getline(ifs,s[99]);
    }//endwhile
    ifs.close();
  }//end ReadFile

};//end class Transcr




int main(int argc,char** argv){

  vector<int> v(100);
  vector<double> d(100);
  vector<string> s(100);
  stringstream ss;

  if(argc!=3){cout<<"Error in usage! : $./CompareTranscrMultiVoice true_transcr.txt est_transcr.txt"<<endl; return -1;}

  string trueFile=string(argv[1]);
  string estFile=string(argv[2]);

  double shiftCost=1;
  double scaleCost=1.0001;

  Transcr transcrTrue;
  transcrTrue.ReadFile(trueFile);
  Transcr transcrEst;
  transcrEst.ReadFile(estFile);

  assert(transcrTrue.evts.size()==transcrEst.evts.size());
  int length=transcrTrue.evts.size();

  for(int i=0;i<length;i+=1){
    transcrTrue.evts[i].normStime=IrredFrac(transcrTrue.evts[i].stime,transcrTrue.TPQN);
    transcrEst.evts[i].normStime=IrredFrac(transcrEst.evts[i].stime,transcrEst.TPQN);
  }//endfor i

  vector<IrredFrac> normNVTrue;
  vector<IrredFrac> normNVEst;
  int preL=0;
  int preR=0;
  for(int n=1;n<length;n+=1){
    if(transcrEst.evts[n].chan==0){//left-hand
      normNVTrue.push_back(SubtrIrredFrac(transcrTrue.evts[n].normStime,transcrTrue.evts[preL].normStime));
      normNVEst.push_back(SubtrIrredFrac(transcrEst.evts[n].normStime,transcrEst.evts[preL].normStime));
      preL=n;
    }else{//if right-hand
      normNVTrue.push_back(SubtrIrredFrac(transcrTrue.evts[n].normStime,transcrTrue.evts[preR].normStime));
      normNVEst.push_back(SubtrIrredFrac(transcrEst.evts[n].normStime,transcrEst.evts[preR].normStime));
      preR=n;
    }//endif
  }//endfor n

  int nuAll[]={384,192,96,48,24,12,576,288,144,72,36,18,672,336,168,84,42,21,256,128,64,32,16,8};
  vector<IrredFrac> scales;
  scales.push_back(IrredFrac(1,1));
  for(int i=0;i<24;i+=1)for(int j=0;j<24;j+=1){
    if(i==j){continue;}
    int foundPos=-1;
    for(int k=0;k<scales.size();k+=1){
      if(scales[k].num==IrredFrac(nuAll[i],nuAll[j]).num && scales[k].den==IrredFrac(nuAll[i],nuAll[j]).den){foundPos=k;}
    }//endfor k
    scales.push_back(IrredFrac(nuAll[i],nuAll[j]));
  }//endfor i,j

//////Viterbiでの最小コスト探索
  vector<double> cost;

////// // 初期化
  cost.assign(scales.size(),scaleCost);
  cost[0]=0;
  for(int k=0;k<scales.size();k+=1){
    if(SubtrIrredFrac(normNVTrue[0],MultIrredFrac(scales[k],normNVEst[0])).num==0){
      cost[k]+=0;
    }else{
      cost[k]+=shiftCost;
    }//endif
  }//endfor k

  vector<int> amin;
  amin.assign(scales.size(),0);
  vector<vector<int> > aminHist;
  for(int n=1;n<length-1;n+=1){
    vector<double> preCost(cost);
    for(int i=0;i<scales.size();i+=1){
      cost[i]=preCost[0]+scaleCost;
      amin[i]=0;
      for(int j=0;j<scales.size();j+=1){
        double tmpCost=preCost[j]+((i==j)? 0:scaleCost);
        if(tmpCost<cost[i]){
          cost[i]=tmpCost;
          amin[i]=j;
        }//endif
      }//endfor j
      if(SubtrIrredFrac(normNVTrue[n],MultIrredFrac(scales[i],normNVEst[n])).num!=0){
        cost[i]+=shiftCost;
      }//endif
    }//endfor i
    aminHist.push_back(amin);
  }//endfor n

  double minCost_=cost[0];
  int amin_=0;
  for(int i=0;i<scales.size();i+=1){
    if(cost[i]<minCost_){
      minCost_=cost[i];
      amin_=i;
    }//endif
  }//endfor i

  cout<<argv[2]<<"\t"<<length<<"\t"<<minCost_<<"\t"<<minCost_/length<<endl;

  return 0;
}//end main

