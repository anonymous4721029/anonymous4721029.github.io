#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include "NoteHMM_v161223.hpp"
using namespace std;

int main(int argc,char** argv){

	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=3){cout<<"Error in usage! : $./RT_NoteHMM in_transcr.txt result_transcr.txt"<<endl; return -1;}

	NoteHMM hmm;
	hmm.ReadData_Transcr(string(argv[1]));
	hmm.Viterbi();
	hmm.WriteFile(string(argv[2]));

	return 0;
}//end main
