#ifndef PIANOROLL_HPP
#define PIANOROLL_HPP

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<cmath>
#include<cassert>
#include"BasicPitchCalculation_v150629.hpp"
#include"Midi_v160504.hpp"
using namespace std;

class PianoRollEvt{
public:
  PianoRollEvt(){}//end PianoRollEvt
  ~PianoRollEvt(){}//end ~PianoRollEvt
  string ID;
  double ontime;
  double offtime;
  string sitch;//spelled pitch
  int pitch;//integral pitch
  int onvel;
  int offvel;
  int channel;
};//end class PianoRollEvt

class PianoRoll{
public:
  PianoRoll(){}//end PianoRoll
  ~PianoRoll(){}//end ~PianoRoll
  vector<string> comments;
  vector<PianoRollEvt> prEvts;

  void ReadFileSpr(string sprFile){
    comments.clear();
    prEvts.clear();
    vector<int> v(100);
    vector<double> d(100);
    vector<string> s(100);
    stringstream ss;
    PianoRollEvt prEvt;
    ifstream ifs(sprFile.c_str());
    while(ifs>>s[0]){
      if(s[0].find("/")!=string::npos){
        getline(ifs,s[99]);
        ss.str("");
        ss<<s[0]<<" "<<s[99];
        comments.push_back(ss.str());
        continue;
      }//endif
      ifs>>d[1]>>d[2]>>s[3]>>v[4]>>v[5]>>v[6];
      prEvt.ID=s[0];
      prEvt.ontime=d[1];
      prEvt.offtime=d[2];
      prEvt.sitch=s[3];
      prEvt.pitch=SitchToPitch(s[3]);
      prEvt.onvel=v[4];
      prEvt.offvel=v[5];
      prEvt.channel=v[6];
      prEvts.push_back(prEvt);
      getline(ifs,s[99]);
    }//endwhile
    ifs.close();
  }//end ReadFileSpr

  void ReadFileIpr(string iprFile){//Note that pitch->sitch is not unique!
    comments.clear();
    prEvts.clear();
    vector<int> v(100);
    vector<double> d(100);
    vector<string> s(100);
    stringstream ss;
    PianoRollEvt prEvt;
    ifstream ifs(iprFile.c_str());
    while(ifs>>s[0]){
      if(s[0].find("/")!=string::npos){
        getline(ifs,s[99]);
        ss.str("");
        ss<<s[0]<<" "<<s[99];
        comments.push_back(ss.str());
        continue;
      }//endif
      ifs>>d[1]>>d[2]>>v[3]>>v[4]>>v[5]>>v[6];
      prEvt.ID=s[0];
      prEvt.ontime=d[1];
      prEvt.offtime=d[2];
      prEvt.sitch=PitchToSitch(v[3]);
      prEvt.pitch=v[3];
      prEvt.onvel=v[4];
      prEvt.offvel=v[5];
      prEvt.channel=v[6];
      prEvts.push_back(prEvt);
      getline(ifs,s[99]);
    }//endwhile
    ifs.close();
  }//end ReadFileIpr

  void ReadMIDIFile(string midiFile){
    comments.clear();
    prEvts.clear();
    Midi midi;
    midi.ReadFile(midiFile);

    int onPosition[16][128];
    for(int i=0;i<16;i+=1)for(int j=0;j<128;j+=1){onPosition[i][j]=-1;}//endfor i,j
    PianoRollEvt prEvt;
    int curChan;

    for(int n=0;n<midi.content.size();n+=1){
      if(midi.content[n].mes[0]>=128 && midi.content[n].mes[0]<160){//note-on or note-off event
        curChan=midi.content[n].mes[0]%16;
        if(midi.content[n].mes[0]>=144 && midi.content[n].mes[2]>0){//note-on
          if(onPosition[curChan][midi.content[n].mes[1]]>=0){
cout<<"Warning: (Double) note-on event before a note-off event"<<endl;
            prEvts[onPosition[curChan][midi.content[n].mes[1]]].offtime=midi.content[n].time;
            prEvts[onPosition[curChan][midi.content[n].mes[1]]].offvel=-1;
          }//endif
          onPosition[curChan][midi.content[n].mes[1]]=prEvts.size();
          prEvt.channel=curChan;
          prEvt.sitch=PitchToSitch(midi.content[n].mes[1]);
          prEvt.pitch=midi.content[n].mes[1];
          prEvt.onvel=midi.content[n].mes[2];
          prEvt.offvel=0;
          prEvt.ontime=midi.content[n].time;
          prEvt.offtime=prEvt.ontime+0.1;
          prEvts.push_back(prEvt);
        }else{//note-off
          if(onPosition[curChan][midi.content[n].mes[1]]<0){
cout<<"Warning: Note-off event before a note-on event"<<endl;
            continue;
          }//endif
          prEvts[onPosition[curChan][midi.content[n].mes[1]]].offtime=midi.content[n].time;
          if(midi.content[n].mes[2]>0){
            prEvts[onPosition[curChan][midi.content[n].mes[1]]].offvel=midi.content[n].mes[2];
          }else{
            prEvts[onPosition[curChan][midi.content[n].mes[1]]].offvel=80;
          }//endif
          onPosition[curChan][midi.content[n].mes[1]]=-1;
        }//endif
      }//endif
    }//endfor n

    for(int i=0;i<16;i+=1)for(int j=0;j<128;j+=1){
      if(onPosition[i][j]>=0){
cout<<"Error: Note without a note-off event"<<endl;
cout<<"ontime channel sitch : "<<prEvts[onPosition[i][j]].ontime<<"\t"<<prEvts[onPosition[i][j]].channel<<"\t"<<prEvts[onPosition[i][j]].sitch<<endl;
        return;
      }//endif
    }//endfor i,j

    for(int n=0;n<prEvts.size();n+=1){
      stringstream ss;
      ss.str(""); ss<<n;
      prEvts[n].ID=ss.str();
    }//endfor n

  }//end ReadMIDIFile

  void WriteFileSpr(string outputFile){
    ofstream ofs(outputFile.c_str());
    ofs<<"//made by midi2pianoroll_v?????"<<"\n";
    for(int i=0;i<comments.size();i+=1){
      ofs<<comments[i]<<endl;
    }//endfor i
    for(int n=0;n<prEvts.size();n+=1){
      PianoRollEvt prEvt=prEvts[n];
      ofs<<prEvt.ID<<"\t"<<prEvt.ontime<<"\t"<<prEvt.offtime<<"\t"<<prEvt.sitch<<"\t"<<prEvt.onvel<<"\t"<<prEvt.offvel<<"\t"<<prEvt.channel<<"\n";
    }//endfor n
    ofs.close();
  }//end WriteFileSpr

  void WriteFileIpr(string outputFile){
    ofstream ofs(outputFile.c_str());
    ofs<<"//made by midi2pianoroll_v?????"<<"\n";
    for(int i=0;i<comments.size();i+=1){
      ofs<<comments[i]<<endl;
    }//endfor i
    for(int n=0;n<prEvts.size();n+=1){
      PianoRollEvt prEvt=prEvts[n];
      ofs<<prEvt.ID<<"\t"<<prEvt.ontime<<"\t"<<prEvt.offtime<<"\t"<<prEvt.pitch<<"\t"<<prEvt.onvel<<"\t"<<prEvt.offvel<<"\t"<<prEvt.channel<<"\n";
    }//endfor n
    ofs.close();
  }//end WriteFileIpr

  Midi ToMidi(){
    Midi midi;

    midi.content.clear();

    MidiMessage midiMes;
    for(int i=0;i<prEvts.size();i+=1){
      midiMes.time=prEvts[i].ontime;
      midiMes.mes.assign(3,0);
      midiMes.mes[0]=144+prEvts[i].channel;
      midiMes.mes[1]=prEvts[i].pitch;
      midiMes.mes[2]=prEvts[i].onvel;
      midi.content.push_back(midiMes);

      midiMes.time=prEvts[i].offtime;
      midiMes.mes.assign(3,0);
      midiMes.mes[0]=128+prEvts[i].channel;
      midiMes.mes[1]=prEvts[i].pitch;
      midiMes.mes[2]=((prEvts[i].offvel>0)? prEvts[i].offvel:80);
      midi.content.push_back(midiMes);
    }//endfor i
    stable_sort(midi.content.begin(),midi.content.end(),LessMidiMessage());
    return midi;

  }//end ToMidi


};//end class PianoRoll

#endif // PIANOROLL_HPP





























