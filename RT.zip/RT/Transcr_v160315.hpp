#ifndef TRANSCR_HPP
#define TRANSCR_HPP

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<cmath>
#include<cassert>
#include "NoteValueCalculation_v160314.hpp"
using namespace std;


class TranscrEvt{
public:
  int ID;
  double ontime;
  double offtime;
  string sitch;
  int onvel;
  int offvel;
  int chan;
  int stime;
  int dur;
  IrredFrac normStime;
};//end class TranscrEvt

class Transcr{
public:
  int TPQN;
  vector<string> comments;
  vector<TranscrEvt> evts;
  double logP;

  void Clear(){
    evts.clear();
    comments.clear();
  }//end Clear

  void ReadFile(string filename){
    comments.clear();
    evts.clear();
    vector<int> v(100);
    vector<double> d(100);
    vector<string> s(100);
    TranscrEvt evt;
    ifstream ifs(filename.c_str());
    while(ifs>>s[0]){
      if(s[0][0]=='/' || s[0][0]=='#'){
        getline(ifs,s[99]);
        istringstream iss(s[99]);
        iss>>s[98];
        if(s[98]=="TPQN:"){iss>>TPQN;}
        comments.push_back(s[99]);
        continue;
      }//endif

      if(s[0]=="end"){
        ifs>>evt.ontime>>evt.stime;
        evt.offtime = -1;
        evt.sitch   = "NA";
        evt.onvel   = -1;
        evt.offvel  = -1;
        evt.chan = 0;
        evt.dur     = 0;
        evts.push_back(evt);
        continue;
      }//endif

      evt.ID      = atoi(s[0].c_str());
      ifs>>evt.ontime>>evt.offtime>>evt.sitch>>evt.onvel>>evt.offvel>>evt.chan>>evt.stime>>evt.dur;
      evts.push_back(evt);

      getline(ifs,s[99]);
    }//endwhile
    ifs.close();
  }//end ReadFile

  void WriteFile(string filename){
    ofstream ofs(filename.c_str());
ofs<<"// TPQN: "<<TPQN<<"\n";
ofs<<"// log prob "<<logP<<"\n";
    TranscrEvt evt;
    for(int n=0;n<evts.size()-1;n+=1){
    evt=evts[n];
ofs<<n<<"\t"<<evt.ontime<<"\t"<<evt.offtime<<"\t"<<evt.sitch<<"\t"<<evt.onvel<<"\t"<<evt.offvel<<"\t"<<evt.chan<<"\t"<<evt.stime<<"\t"<<evt.dur<<"\n";
    }//endfor n
    evt=evts[evts.size()-1];
ofs<<"end"<<"\t"<<evt.ontime<<"\t"<<evt.stime<<"\n";
    ofs.close();
  }//end WriteFile

};//end class Transcr


#endif // TRANSCR_HPP





























