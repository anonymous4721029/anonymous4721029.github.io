#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include "MetricalHMM_v161223.hpp"
using namespace std;

int main(int argc,char** argv){

  vector<int> v(100);
  vector<double> d(100);
  vector<string> s(100);
  stringstream ss;

  if(argc!=3){cout<<"Error in usage! : $./RT_MetricalHMM in_transcr.txt result_transcr.txt"<<endl; return -1;}

  MetricalHMM hmm;
  hmm.ReadData_Transcr(string(argv[1]));
  hmm.Viterbi();
  hmm.WriteFile(string(argv[2]));


  return 0;
}//end main
