#ifndef MERGEDOUTPUTHMM_HPP
#define MERGEDOUTPUTHMM_HPP

#define printOn false
#define TPQN_ 24

#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include <vector>
#include <fstream>
#include <cassert>
#include <algorithm>
#include "Transcr_v160315.hpp"
#include "BasicPitchCalculation_v150629.hpp"
using namespace std;

inline double LogAdd(double d1,double d2){
//log(exp(d1)+exp(d2))=log(exp(d1)(1+exp(d2-d1)))
	if(d1>d2){return d1+log(1+exp(d2-d1));
	}else{return d2+log(1+exp(d1-d2));
	}//endif
}//end LogAdd
inline void norm(vector<double>& vd){
	double sum=0;
	for(int i=0;i<vd.size();i+=1){sum+=vd[i];if(vd[i]<0){cout<<"negative weight!"<<endl;}}
	for(int i=0;i<vd.size();i+=1){vd[i]/=sum;}
	return;
}//
inline void lognorm(vector<double>& vd){
	double tmpd=vd[0];
	for(int i=0;i<vd.size();i+=1){if(vd[i]>tmpd){tmpd=vd[i];}}//endfor i
	for(int i=0;i<vd.size();i+=1){vd[i]-=tmpd;}//endfor i
	tmpd=0;
	for(int i=0;i<vd.size();i+=1){tmpd+=exp(vd[i]);}//endfor i
	tmpd=log(tmpd);
	for(int i=0;i<vd.size();i+=1){vd[i]-=tmpd;if(vd[i]<-200){vd[i]=-200;}}//endfor i
}//

class Prob{
public:
	vector<double> P;
	vector<double> LP;

	void Normalize(){
		norm(P);
		PToLP();
	}//end Normalize

	void PToLP(){
		LP.clear();
		LP.resize(P.size());
		for(int i=0;i<P.size();i+=1){
			LP[i]=log(P[i]);
		}//endfor i
	}//end PToLP

	void LPToP(){
		P.clear();
		P.resize(LP.size());
		for(int i=0;i<LP.size();i+=1){
			P[i]=exp(LP[i]);
		}//endfor i
	}//end LPToP

};//endclass Prob


class MergedOutputHMM{
public:
	int TPQN;
	Transcr data;

	vector<int> nv;
	int numNoteValue;
	int numNVStates;

	Prob voiceProb;//0:left-hand, 1:right-hand

	vector<Prob> trProb;
	Prob trIniProb;
	vector<Prob> stateInProb;//stateInProb[r].P[0]=a^r_in,s
	vector<Prob> stateStayProb;//stateStayProb[r].P[0]=a^r_s,s

	vector<Prob> pitchIntProb;

	double sigma_p;
	double sigma_p_ini;

	double sigma_t;//オンセット時刻のノイズの標準偏差
	double lambda;//chordal IOIの指数分布のscale parameter
	vector<double> secPerQN;
	vector<Prob> tempoTrProb;
	Prob tempoTrIniProb;
	int numTempoState;
	double minSecPerQN,maxSeqPerQN;
	int truncatedWidth;
	double outerLP;
	int Nh;

	double fac_sigma_p;
	double fac_sigma_p_ini;
	double fac_sigma_t;
	double fac_lambda;

	MergedOutputHMM(){
		Init();
	}//end MergedOutputHMM
	~MergedOutputHMM(){}//end ~MergedOutputHMM

	void Init(){
if(printOn){cout<<"###Init###"<<endl;}

		TPQN=TPQN_;

		sigma_p=5.;
		sigma_p_ini=12.;
		Nh=30;

		int nvList[]={96,72,64,48,36,32,24,18,16,12,9,8,6,4,3};
		numNoteValue=15;
		nv.clear();
		for(int i=0;i<numNoteValue;i+=1){
			nv.push_back(nvList[i]);
		}//endfor i
		numNVStates=2*numNoteValue;


//Set note-value probabilities
		trProb.resize(numNoteValue);
		stateInProb.resize(numNoteValue);
		stateStayProb.resize(numNoteValue);
		for(int i=0;i<numNoteValue;i+=1){
			trProb[i].P.resize(numNoteValue);
			stateInProb[i].P.resize(2);
			stateStayProb[i].P.resize(2);
		}//endfor i
		trIniProb.P.resize(numNoteValue);

		stateInProb[0].P[0]=0.772156;	stateStayProb[0].P[0]=0.82612;
		stateInProb[1].P[0]=0.876323;	stateStayProb[1].P[0]=0.801412;
		stateInProb[2].P[0]=0.989899;	stateStayProb[2].P[0]=0.980583;
		stateInProb[3].P[0]=0.898658;	stateStayProb[3].P[0]=0.799889;
		stateInProb[4].P[0]=0.891985;	stateStayProb[4].P[0]=0.797928;
		stateInProb[5].P[0]=0.989899;	stateStayProb[5].P[0]=0.980583;
		stateInProb[6].P[0]=0.74746;	stateStayProb[6].P[0]=0.769629;
		stateInProb[7].P[0]=0.783911;	stateStayProb[7].P[0]=0.786074;
		stateInProb[8].P[0]=0.355793;	stateStayProb[8].P[0]=0.792661;
		stateInProb[9].P[0]=0.560302;	stateStayProb[9].P[0]=0.737182;
		stateInProb[10].P[0]=0.564169;	stateStayProb[10].P[0]=0.786676;
		stateInProb[11].P[0]=0.305673;	stateStayProb[11].P[0]=0.719369;
		stateInProb[12].P[0]=0.425348;	stateStayProb[12].P[0]=0.719093;
		stateInProb[13].P[0]=0.273423;	stateStayProb[13].P[0]=0.717485;
		stateInProb[14].P[0]=0.304418;	stateStayProb[14].P[0]=0.723008;
		trProb[0].P[0]=0.503665;	trProb[0].P[1]=0.0534031;	trProb[0].P[2]=0.00104712;	trProb[0].P[3]=0.0743455;	trProb[0].P[4]=0.00104712;	trProb[0].P[5]=0.00104712;	trProb[0].P[6]=0.137173;	trProb[0].P[7]=0.0324607;	trProb[0].P[8]=0.00104712;	trProb[0].P[9]=0.126702;	trProb[0].P[10]=0.00104712;	trProb[0].P[11]=0.0534031;	trProb[0].P[12]=0.0115183;	trProb[0].P[13]=0.00104712;	trProb[0].P[14]=0.00104712;	
		trProb[1].P[0]=0.000400802;	trProb[1].P[1]=0.248898;	trProb[1].P[2]=0.000400802;	trProb[1].P[3]=0.120641;	trProb[1].P[4]=0.044489;	trProb[1].P[5]=0.000400802;	trProb[1].P[6]=0.333066;	trProb[1].P[7]=0.00841683;	trProb[1].P[8]=0.000400802;	trProb[1].P[9]=0.160721;	trProb[1].P[10]=0.00440882;	trProb[1].P[11]=0.052505;	trProb[1].P[12]=0.0244489;	trProb[1].P[13]=0.000400802;	trProb[1].P[14]=0.000400802;	
		trProb[2].P[0]=0.0666667;	trProb[2].P[1]=0.0666667;	trProb[2].P[2]=0.0666667;	trProb[2].P[3]=0.0666667;	trProb[2].P[4]=0.0666667;	trProb[2].P[5]=0.0666667;	trProb[2].P[6]=0.0666667;	trProb[2].P[7]=0.0666667;	trProb[2].P[8]=0.0666667;	trProb[2].P[9]=0.0666667;	trProb[2].P[10]=0.0666667;	trProb[2].P[11]=0.0666667;	trProb[2].P[12]=0.0666667;	trProb[2].P[13]=0.0666667;	trProb[2].P[14]=0.0666667;	
		trProb[3].P[0]=0.00863079;	trProb[3].P[1]=0.0224827;	trProb[3].P[2]=0.000106553;	trProb[3].P[3]=0.16846;	trProb[3].P[4]=0.0416622;	trProb[3].P[5]=0.000106553;	trProb[3].P[6]=0.472136;	trProb[3].P[7]=0.0437933;	trProb[3].P[8]=0.000106553;	trProb[3].P[9]=0.174853;	trProb[3].P[10]=0.00117208;	trProb[3].P[11]=0.0107619;	trProb[3].P[12]=0.0469899;	trProb[3].P[13]=0.00436867;	trProb[3].P[14]=0.00436867;	
		trProb[4].P[0]=0.00208024;	trProb[4].P[1]=0.0119861;	trProb[4].P[2]=9.90589e-05;	trProb[4].P[3]=0.00703318;	trProb[4].P[4]=0.268549;	trProb[4].P[5]=9.90589e-05;	trProb[4].P[6]=0.0615156;	trProb[4].P[7]=0.0109955;	trProb[4].P[8]=9.90589e-05;	trProb[4].P[9]=0.466667;	trProb[4].P[10]=0.00406142;	trProb[4].P[11]=9.90589e-05;	trProb[4].P[12]=0.115998;	trProb[4].P[13]=0.0357603;	trProb[4].P[14]=0.0149579;	
		trProb[5].P[0]=0.0666667;	trProb[5].P[1]=0.0666667;	trProb[5].P[2]=0.0666667;	trProb[5].P[3]=0.0666667;	trProb[5].P[4]=0.0666667;	trProb[5].P[5]=0.0666667;	trProb[5].P[6]=0.0666667;	trProb[5].P[7]=0.0666667;	trProb[5].P[8]=0.0666667;	trProb[5].P[9]=0.0666667;	trProb[5].P[10]=0.0666667;	trProb[5].P[11]=0.0666667;	trProb[5].P[12]=0.0666667;	trProb[5].P[13]=0.0666667;	trProb[5].P[14]=0.0666667;	
		trProb[6].P[0]=0.00141881;	trProb[6].P[1]=0.0076757;	trProb[6].P[2]=8.81251e-06;	trProb[6].P[3]=0.0408108;	trProb[6].P[4]=0.0161357;	trProb[6].P[5]=8.81251e-06;	trProb[6].P[6]=0.642265;	trProb[6].P[7]=0.0260057;	trProb[6].P[8]=8.81251e-06;	trProb[6].P[9]=0.209042;	trProb[6].P[10]=0.00194757;	trProb[6].P[11]=0.0087332;	trProb[6].P[12]=0.0371095;	trProb[6].P[13]=0.00291694;	trProb[6].P[14]=0.0059132;	
		trProb[7].P[0]=7.18133e-05;	trProb[7].P[1]=7.18133e-05;	trProb[7].P[2]=7.18133e-05;	trProb[7].P[3]=7.18133e-05;	trProb[7].P[4]=0.00294434;	trProb[7].P[5]=7.18133e-05;	trProb[7].P[6]=0.0151526;	trProb[7].P[7]=0.0374147;	trProb[7].P[8]=7.18133e-05;	trProb[7].P[9]=0.0137163;	trProb[7].P[10]=7.18133e-05;	trProb[7].P[11]=7.18133e-05;	trProb[7].P[12]=0.872603;	trProb[7].P[13]=7.18133e-05;	trProb[7].P[14]=0.0575224;	
		trProb[8].P[0]=0.000843882;	trProb[8].P[1]=0.000843882;	trProb[8].P[2]=0.000843882;	trProb[8].P[3]=0.000843882;	trProb[8].P[4]=0.000843882;	trProb[8].P[5]=0.000843882;	trProb[8].P[6]=0.000843882;	trProb[8].P[7]=0.000843882;	trProb[8].P[8]=0.912236;	trProb[8].P[9]=0.0177215;	trProb[8].P[10]=0.000843882;	trProb[8].P[11]=0.0514768;	trProb[8].P[12]=0.000843882;	trProb[8].P[13]=0.0092827;	trProb[8].P[14]=0.000843882;	
		trProb[9].P[0]=0.00036364;	trProb[9].P[1]=0.00121426;	trProb[9].P[2]=2.12655e-06;	trProb[9].P[3]=0.00338334;	trProb[9].P[4]=0.00765771;	trProb[9].P[5]=2.12655e-06;	trProb[9].P[6]=0.0503801;	trProb[9].P[7]=0.00525471;	trProb[9].P[8]=4.46576e-05;	trProb[9].P[9]=0.870718;	trProb[9].P[10]=0.00221374;	trProb[9].P[11]=0.00078895;	trProb[9].P[12]=0.0491467;	trProb[9].P[13]=0.00444662;	trProb[9].P[14]=0.00438282;	
		trProb[10].P[0]=0.000187441;	trProb[10].P[1]=0.000187441;	trProb[10].P[2]=0.000187441;	trProb[10].P[3]=0.000187441;	trProb[10].P[4]=0.00206186;	trProb[10].P[5]=0.000187441;	trProb[10].P[6]=0.00206186;	trProb[10].P[7]=0.00393627;	trProb[10].P[8]=0.000187441;	trProb[10].P[9]=0.0226804;	trProb[10].P[10]=0.182006;	trProb[10].P[11]=0.00206186;	trProb[10].P[12]=0.0133083;	trProb[10].P[13]=0.000187441;	trProb[10].P[14]=0.770572;	
		trProb[11].P[0]=0.000611328;	trProb[11].P[1]=0.000131855;	trProb[11].P[2]=1.19868e-05;	trProb[11].P[3]=0.0014504;	trProb[11].P[4]=1.19868e-05;	trProb[11].P[5]=1.19868e-05;	trProb[11].P[6]=0.0125981;	trProb[11].P[7]=1.19868e-05;	trProb[11].P[8]=0.000851064;	trProb[11].P[9]=0.00396764;	trProb[11].P[10]=1.19868e-05;	trProb[11].P[11]=0.949488;	trProb[11].P[12]=0.00324843;	trProb[11].P[13]=0.0275817;	trProb[11].P[14]=1.19868e-05;	
		trProb[12].P[0]=4.14419e-05;	trProb[12].P[1]=0.000121652;	trProb[12].P[2]=1.33684e-06;	trProb[12].P[3]=0.00145849;	trProb[12].P[4]=0.00152533;	trProb[12].P[5]=1.33684e-06;	trProb[12].P[6]=0.0113243;	trProb[12].P[7]=0.00846351;	trProb[12].P[8]=1.33684e-06;	trProb[12].P[9]=0.0307619;	trProb[12].P[10]=0.000415756;	trProb[12].P[11]=0.000990595;	trProb[12].P[12]=0.92953;	trProb[12].P[13]=0.00144512;	trProb[12].P[14]=0.0139178;	
		trProb[13].P[0]=1.61538e-05;	trProb[13].P[1]=0.000339229;	trProb[13].P[2]=1.61538e-05;	trProb[13].P[3]=0.000985381;	trProb[13].P[4]=0.00260076;	trProb[13].P[5]=1.61538e-05;	trProb[13].P[6]=0.0121315;	trProb[13].P[7]=0.00211615;	trProb[13].P[8]=1.61538e-05;	trProb[13].P[9]=0.0320006;	trProb[13].P[10]=0.00163153;	trProb[13].P[11]=0.0320006;	trProb[13].P[12]=0.0126161;	trProb[13].P[13]=0.898651;	trProb[13].P[14]=0.00486229;	
		trProb[14].P[0]=6.1529e-06;	trProb[14].P[1]=6.76819e-05;	trProb[14].P[2]=6.1529e-06;	trProb[14].P[3]=0.000436856;	trProb[14].P[4]=0.00111367;	trProb[14].P[5]=6.1529e-06;	trProb[14].P[6]=0.00671281;	trProb[14].P[7]=0.00425165;	trProb[14].P[8]=6.1529e-06;	trProb[14].P[9]=0.027202;	trProb[14].P[10]=0.0151423;	trProb[14].P[11]=0.000436856;	trProb[14].P[12]=0.0567359;	trProb[14].P[13]=0.00431318;	trProb[14].P[14]=0.883563;	
		trIniProb.P[0]=0.000649545;	trIniProb.P[1]=0.00158997;	trIniProb.P[2]=9.4065e-06;	trIniProb.P[3]=0.00583544;	trIniProb.P[4]=0.00612119;	trIniProb.P[5]=9.4065e-06;	trIniProb.P[6]=0.0691682;	trIniProb.P[7]=0.0080631;	trIniProb.P[8]=0.000834508;	trIniProb.P[9]=0.279934;	trIniProb.P[10]=0.00297868;	trIniProb.P[11]=0.0596259;	trIniProb.P[12]=0.42993;	trIniProb.P[13]=0.0434327;	trIniProb.P[14]=0.0918171;	

		for(int i=0;i<numNoteValue;i+=1){
			stateInProb[i].P[1]=1-stateInProb[i].P[0];
			stateStayProb[i].P[1]=1-stateStayProb[i].P[0];
		}//endfor i

		for(int i=0;i<numNoteValue;i+=1){
			trProb[i].Normalize();
			stateInProb[i].Normalize();
			stateStayProb[i].Normalize();
		}//endfor i
		trIniProb.Normalize();

		pitchIntProb.resize(2);//for LH and RH;
		pitchIntProb[0].P.resize(256);
		pitchIntProb[1].P.resize(256);

		pitchIntProb[0].P[0]=4.43597e-05;	pitchIntProb[1].P[0]=5.68376e-05;
		pitchIntProb[0].P[1]=4.43597e-05;	pitchIntProb[1].P[1]=5.68376e-05;
		pitchIntProb[0].P[2]=4.43597e-05;	pitchIntProb[1].P[2]=5.68376e-05;
		pitchIntProb[0].P[3]=4.43597e-05;	pitchIntProb[1].P[3]=5.68376e-05;
		pitchIntProb[0].P[4]=4.43597e-05;	pitchIntProb[1].P[4]=5.68376e-05;
		pitchIntProb[0].P[5]=4.43597e-05;	pitchIntProb[1].P[5]=5.68376e-05;
		pitchIntProb[0].P[6]=4.43597e-05;	pitchIntProb[1].P[6]=5.68376e-05;
		pitchIntProb[0].P[7]=4.43597e-05;	pitchIntProb[1].P[7]=5.68376e-05;
		pitchIntProb[0].P[8]=4.43597e-05;	pitchIntProb[1].P[8]=5.68376e-05;
		pitchIntProb[0].P[9]=4.43597e-05;	pitchIntProb[1].P[9]=5.68376e-05;
		pitchIntProb[0].P[10]=4.43597e-05;	pitchIntProb[1].P[10]=5.68376e-05;
		pitchIntProb[0].P[11]=4.43597e-05;	pitchIntProb[1].P[11]=5.68376e-05;
		pitchIntProb[0].P[12]=4.43597e-05;	pitchIntProb[1].P[12]=5.68376e-05;
		pitchIntProb[0].P[13]=4.43597e-05;	pitchIntProb[1].P[13]=5.68376e-05;
		pitchIntProb[0].P[14]=4.43597e-05;	pitchIntProb[1].P[14]=5.68376e-05;
		pitchIntProb[0].P[15]=4.43597e-05;	pitchIntProb[1].P[15]=5.68376e-05;
		pitchIntProb[0].P[16]=4.43597e-05;	pitchIntProb[1].P[16]=5.68376e-05;
		pitchIntProb[0].P[17]=4.43597e-05;	pitchIntProb[1].P[17]=5.68376e-05;
		pitchIntProb[0].P[18]=4.43597e-05;	pitchIntProb[1].P[18]=5.68376e-05;
		pitchIntProb[0].P[19]=4.43597e-05;	pitchIntProb[1].P[19]=5.68376e-05;
		pitchIntProb[0].P[20]=4.43597e-05;	pitchIntProb[1].P[20]=5.68376e-05;
		pitchIntProb[0].P[21]=4.43597e-05;	pitchIntProb[1].P[21]=5.68376e-05;
		pitchIntProb[0].P[22]=4.43597e-05;	pitchIntProb[1].P[22]=5.68376e-05;
		pitchIntProb[0].P[23]=4.43597e-05;	pitchIntProb[1].P[23]=5.68376e-05;
		pitchIntProb[0].P[24]=4.43597e-05;	pitchIntProb[1].P[24]=5.68376e-05;
		pitchIntProb[0].P[25]=4.43597e-05;	pitchIntProb[1].P[25]=5.68376e-05;
		pitchIntProb[0].P[26]=4.43597e-05;	pitchIntProb[1].P[26]=5.68376e-05;
		pitchIntProb[0].P[27]=4.43597e-05;	pitchIntProb[1].P[27]=5.68376e-05;
		pitchIntProb[0].P[28]=4.43597e-05;	pitchIntProb[1].P[28]=5.68376e-05;
		pitchIntProb[0].P[29]=4.43597e-05;	pitchIntProb[1].P[29]=5.68376e-05;
		pitchIntProb[0].P[30]=4.43597e-05;	pitchIntProb[1].P[30]=5.68376e-05;
		pitchIntProb[0].P[31]=4.43597e-05;	pitchIntProb[1].P[31]=5.68376e-05;
		pitchIntProb[0].P[32]=4.43597e-05;	pitchIntProb[1].P[32]=5.68376e-05;
		pitchIntProb[0].P[33]=4.43597e-05;	pitchIntProb[1].P[33]=5.68376e-05;
		pitchIntProb[0].P[34]=4.43597e-05;	pitchIntProb[1].P[34]=5.68376e-05;
		pitchIntProb[0].P[35]=4.43597e-05;	pitchIntProb[1].P[35]=5.68376e-05;
		pitchIntProb[0].P[36]=4.43597e-05;	pitchIntProb[1].P[36]=5.68376e-05;
		pitchIntProb[0].P[37]=4.43597e-05;	pitchIntProb[1].P[37]=5.68376e-05;
		pitchIntProb[0].P[38]=4.43597e-05;	pitchIntProb[1].P[38]=5.68376e-05;
		pitchIntProb[0].P[39]=4.43597e-05;	pitchIntProb[1].P[39]=5.68376e-05;
		pitchIntProb[0].P[40]=4.43597e-05;	pitchIntProb[1].P[40]=5.68376e-05;
		pitchIntProb[0].P[41]=4.43597e-05;	pitchIntProb[1].P[41]=5.68376e-05;
		pitchIntProb[0].P[42]=4.43597e-05;	pitchIntProb[1].P[42]=5.68376e-05;
		pitchIntProb[0].P[43]=4.43597e-05;	pitchIntProb[1].P[43]=5.68376e-05;
		pitchIntProb[0].P[44]=4.43597e-05;	pitchIntProb[1].P[44]=5.68376e-05;
		pitchIntProb[0].P[45]=4.43597e-05;	pitchIntProb[1].P[45]=5.68376e-05;
		pitchIntProb[0].P[46]=4.43597e-05;	pitchIntProb[1].P[46]=5.68376e-05;
		pitchIntProb[0].P[47]=4.43597e-05;	pitchIntProb[1].P[47]=5.68376e-05;
		pitchIntProb[0].P[48]=4.43597e-05;	pitchIntProb[1].P[48]=5.68376e-05;
		pitchIntProb[0].P[49]=4.43597e-05;	pitchIntProb[1].P[49]=5.68376e-05;
		pitchIntProb[0].P[50]=4.43597e-05;	pitchIntProb[1].P[50]=5.68376e-05;
		pitchIntProb[0].P[51]=4.43597e-05;	pitchIntProb[1].P[51]=5.68376e-05;
		pitchIntProb[0].P[52]=4.43597e-05;	pitchIntProb[1].P[52]=5.68376e-05;
		pitchIntProb[0].P[53]=4.43597e-05;	pitchIntProb[1].P[53]=5.68376e-05;
		pitchIntProb[0].P[54]=4.43597e-05;	pitchIntProb[1].P[54]=5.68376e-05;
		pitchIntProb[0].P[55]=4.43597e-05;	pitchIntProb[1].P[55]=5.68376e-05;
		pitchIntProb[0].P[56]=4.43597e-05;	pitchIntProb[1].P[56]=5.68376e-05;
		pitchIntProb[0].P[57]=4.43597e-05;	pitchIntProb[1].P[57]=5.68376e-05;
		pitchIntProb[0].P[58]=4.43597e-05;	pitchIntProb[1].P[58]=5.68376e-05;
		pitchIntProb[0].P[59]=4.43597e-05;	pitchIntProb[1].P[59]=5.68376e-05;
		pitchIntProb[0].P[60]=4.43597e-05;	pitchIntProb[1].P[60]=5.68376e-05;
		pitchIntProb[0].P[61]=4.43597e-05;	pitchIntProb[1].P[61]=5.68376e-05;
		pitchIntProb[0].P[62]=4.43597e-05;	pitchIntProb[1].P[62]=5.68376e-05;
		pitchIntProb[0].P[63]=4.43597e-05;	pitchIntProb[1].P[63]=5.68376e-05;
		pitchIntProb[0].P[64]=4.43597e-05;	pitchIntProb[1].P[64]=5.68376e-05;
		pitchIntProb[0].P[65]=4.43597e-05;	pitchIntProb[1].P[65]=5.68376e-05;
		pitchIntProb[0].P[66]=4.43597e-05;	pitchIntProb[1].P[66]=5.68376e-05;
		pitchIntProb[0].P[67]=4.43597e-05;	pitchIntProb[1].P[67]=5.68376e-05;
		pitchIntProb[0].P[68]=4.43597e-05;	pitchIntProb[1].P[68]=5.68376e-05;
		pitchIntProb[0].P[69]=4.43597e-05;	pitchIntProb[1].P[69]=5.68376e-05;
		pitchIntProb[0].P[70]=4.43597e-05;	pitchIntProb[1].P[70]=5.68376e-05;
		pitchIntProb[0].P[71]=4.43597e-05;	pitchIntProb[1].P[71]=5.68376e-05;
		pitchIntProb[0].P[72]=4.43597e-05;	pitchIntProb[1].P[72]=5.68376e-05;
		pitchIntProb[0].P[73]=4.43597e-05;	pitchIntProb[1].P[73]=5.68376e-05;
		pitchIntProb[0].P[74]=4.43597e-05;	pitchIntProb[1].P[74]=0.000113675;
		pitchIntProb[0].P[75]=4.43597e-05;	pitchIntProb[1].P[75]=5.68376e-05;
		pitchIntProb[0].P[76]=4.43597e-05;	pitchIntProb[1].P[76]=5.68376e-05;
		pitchIntProb[0].P[77]=4.43597e-05;	pitchIntProb[1].P[77]=5.68376e-05;
		pitchIntProb[0].P[78]=4.43597e-05;	pitchIntProb[1].P[78]=5.68376e-05;
		pitchIntProb[0].P[79]=4.43597e-05;	pitchIntProb[1].P[79]=5.68376e-05;
		pitchIntProb[0].P[80]=4.43597e-05;	pitchIntProb[1].P[80]=5.68376e-05;
		pitchIntProb[0].P[81]=4.43597e-05;	pitchIntProb[1].P[81]=5.68376e-05;
		pitchIntProb[0].P[82]=4.43597e-05;	pitchIntProb[1].P[82]=5.68376e-05;
		pitchIntProb[0].P[83]=4.43597e-05;	pitchIntProb[1].P[83]=5.68376e-05;
		pitchIntProb[0].P[84]=4.43597e-05;	pitchIntProb[1].P[84]=5.68376e-05;
		pitchIntProb[0].P[85]=0.000133079;	pitchIntProb[1].P[85]=0.000113675;
		pitchIntProb[0].P[86]=4.43597e-05;	pitchIntProb[1].P[86]=0.000170513;
		pitchIntProb[0].P[87]=4.43597e-05;	pitchIntProb[1].P[87]=5.68376e-05;
		pitchIntProb[0].P[88]=4.43597e-05;	pitchIntProb[1].P[88]=0.000170513;
		pitchIntProb[0].P[89]=4.43597e-05;	pitchIntProb[1].P[89]=0.000113675;
		pitchIntProb[0].P[90]=4.43597e-05;	pitchIntProb[1].P[90]=0.00022735;
		pitchIntProb[0].P[91]=4.43597e-05;	pitchIntProb[1].P[91]=5.68376e-05;
		pitchIntProb[0].P[92]=0.000266158;	pitchIntProb[1].P[92]=0.000170513;
		pitchIntProb[0].P[93]=4.43597e-05;	pitchIntProb[1].P[93]=5.68376e-05;
		pitchIntProb[0].P[94]=8.87193e-05;	pitchIntProb[1].P[94]=0.000284188;
		pitchIntProb[0].P[95]=8.87193e-05;	pitchIntProb[1].P[95]=0.000170513;
		pitchIntProb[0].P[96]=4.43597e-05;	pitchIntProb[1].P[96]=5.68376e-05;
		pitchIntProb[0].P[97]=0.000133079;	pitchIntProb[1].P[97]=0.000511538;
		pitchIntProb[0].P[98]=0.000133079;	pitchIntProb[1].P[98]=0.000170513;
		pitchIntProb[0].P[99]=8.87193e-05;	pitchIntProb[1].P[99]=0.0004547;
		pitchIntProb[0].P[100]=0.000177439;	pitchIntProb[1].P[100]=0.00022735;
		pitchIntProb[0].P[101]=0.000133079;	pitchIntProb[1].P[101]=0.000113675;
		pitchIntProb[0].P[102]=0.000221798;	pitchIntProb[1].P[102]=0.0004547;
		pitchIntProb[0].P[103]=4.43597e-05;	pitchIntProb[1].P[103]=5.68376e-05;
		pitchIntProb[0].P[104]=0.000354877;	pitchIntProb[1].P[104]=0.00102308;
		pitchIntProb[0].P[105]=0.000133079;	pitchIntProb[1].P[105]=0.000341025;
		pitchIntProb[0].P[106]=0.000399237;	pitchIntProb[1].P[106]=0.00102308;
		pitchIntProb[0].P[107]=0.000266158;	pitchIntProb[1].P[107]=0.000682051;
		pitchIntProb[0].P[108]=0.000887193;	pitchIntProb[1].P[108]=0.00125043;
		pitchIntProb[0].P[109]=0.000354877;	pitchIntProb[1].P[109]=0.0018188;
		pitchIntProb[0].P[110]=0.000576676;	pitchIntProb[1].P[110]=0.000852563;
		pitchIntProb[0].P[111]=0.000798474;	pitchIntProb[1].P[111]=0.00255769;
		pitchIntProb[0].P[112]=0.000842834;	pitchIntProb[1].P[112]=0.00233034;
		pitchIntProb[0].P[113]=0.00181875;	pitchIntProb[1].P[113]=0.00323974;
		pitchIntProb[0].P[114]=0.00261722;	pitchIntProb[1].P[114]=0.00505854;
		pitchIntProb[0].P[115]=0.00137515;	pitchIntProb[1].P[115]=0.00244402;
		pitchIntProb[0].P[116]=0.0272368;	pitchIntProb[1].P[116]=0.0352961;
		pitchIntProb[0].P[117]=0.00882757;	pitchIntProb[1].P[117]=0.00670683;
		pitchIntProb[0].P[118]=0.0122876;	pitchIntProb[1].P[118]=0.0127316;
		pitchIntProb[0].P[119]=0.0208047;	pitchIntProb[1].P[119]=0.0149483;
		pitchIntProb[0].P[120]=0.0139289;	pitchIntProb[1].P[120]=0.0158577;
		pitchIntProb[0].P[121]=0.0245753;	pitchIntProb[1].P[121]=0.0412641;
		pitchIntProb[0].P[122]=0.0179213;	pitchIntProb[1].P[122]=0.0179607;
		pitchIntProb[0].P[123]=0.0357539;	pitchIntProb[1].P[123]=0.0327384;
		pitchIntProb[0].P[124]=0.042186;	pitchIntProb[1].P[124]=0.0397295;
		pitchIntProb[0].P[125]=0.0628576;	pitchIntProb[1].P[125]=0.0624645;
		pitchIntProb[0].P[126]=0.117642;	pitchIntProb[1].P[126]=0.0970785;
		pitchIntProb[0].P[127]=0.0884532;	pitchIntProb[1].P[127]=0.0649653;
		pitchIntProb[0].P[128]=0.0362862;	pitchIntProb[1].P[128]=0.0284756;
		pitchIntProb[0].P[129]=0.0920907;	pitchIntProb[1].P[129]=0.069285;
		pitchIntProb[0].P[130]=0.0904494;	pitchIntProb[1].P[130]=0.0925315;
		pitchIntProb[0].P[131]=0.0626802;	pitchIntProb[1].P[131]=0.0816187;
		pitchIntProb[0].P[132]=0.0440048;	pitchIntProb[1].P[132]=0.0518927;
		pitchIntProb[0].P[133]=0.0435612;	pitchIntProb[1].P[133]=0.051438;
		pitchIntProb[0].P[134]=0.0162356;	pitchIntProb[1].P[134]=0.013982;
		pitchIntProb[0].P[135]=0.023555;	pitchIntProb[1].P[135]=0.0309765;
		pitchIntProb[0].P[136]=0.0185423;	pitchIntProb[1].P[136]=0.013982;
		pitchIntProb[0].P[137]=0.0222242;	pitchIntProb[1].P[137]=0.0143799;
		pitchIntProb[0].P[138]=0.0121102;	pitchIntProb[1].P[138]=0.00932136;
		pitchIntProb[0].P[139]=0.00842834;	pitchIntProb[1].P[139]=0.00215983;
		pitchIntProb[0].P[140]=0.0279022;	pitchIntProb[1].P[140]=0.0395589;
		pitchIntProb[0].P[141]=0.000842834;	pitchIntProb[1].P[141]=0.00125043;
		pitchIntProb[0].P[142]=0.00119771;	pitchIntProb[1].P[142]=0.00335342;
		pitchIntProb[0].P[143]=0.00173003;	pitchIntProb[1].P[143]=0.00380812;
		pitchIntProb[0].P[144]=0.00119771;	pitchIntProb[1].P[144]=0.0022735;
		pitchIntProb[0].P[145]=0.000621035;	pitchIntProb[1].P[145]=0.00193248;
		pitchIntProb[0].P[146]=8.87193e-05;	pitchIntProb[1].P[146]=0.000795726;
		pitchIntProb[0].P[147]=0.000354877;	pitchIntProb[1].P[147]=0.00238718;
		pitchIntProb[0].P[148]=0.000576676;	pitchIntProb[1].P[148]=0.000795726;
		pitchIntProb[0].P[149]=0.000354877;	pitchIntProb[1].P[149]=0.0004547;
		pitchIntProb[0].P[150]=0.000177439;	pitchIntProb[1].P[150]=0.000966238;
		pitchIntProb[0].P[151]=8.87193e-05;	pitchIntProb[1].P[151]=0.000113675;
		pitchIntProb[0].P[152]=0.000487956;	pitchIntProb[1].P[152]=0.00147778;
		pitchIntProb[0].P[153]=4.43597e-05;	pitchIntProb[1].P[153]=5.68376e-05;
		pitchIntProb[0].P[154]=0.000177439;	pitchIntProb[1].P[154]=0.000511538;
		pitchIntProb[0].P[155]=8.87193e-05;	pitchIntProb[1].P[155]=0.00022735;
		pitchIntProb[0].P[156]=4.43597e-05;	pitchIntProb[1].P[156]=0.000341025;
		pitchIntProb[0].P[157]=0.000177439;	pitchIntProb[1].P[157]=0.000170513;
		pitchIntProb[0].P[158]=4.43597e-05;	pitchIntProb[1].P[158]=0.00022735;
		pitchIntProb[0].P[159]=0.000133079;	pitchIntProb[1].P[159]=0.00022735;
		pitchIntProb[0].P[160]=0.000133079;	pitchIntProb[1].P[160]=0.000170513;
		pitchIntProb[0].P[161]=0.000133079;	pitchIntProb[1].P[161]=5.68376e-05;
		pitchIntProb[0].P[162]=0.000354877;	pitchIntProb[1].P[162]=0.000170513;
		pitchIntProb[0].P[163]=4.43597e-05;	pitchIntProb[1].P[163]=5.68376e-05;
		pitchIntProb[0].P[164]=0.000133079;	pitchIntProb[1].P[164]=0.000113675;
		pitchIntProb[0].P[165]=4.43597e-05;	pitchIntProb[1].P[165]=5.68376e-05;
		pitchIntProb[0].P[166]=8.87193e-05;	pitchIntProb[1].P[166]=5.68376e-05;
		pitchIntProb[0].P[167]=4.43597e-05;	pitchIntProb[1].P[167]=5.68376e-05;
		pitchIntProb[0].P[168]=0.000133079;	pitchIntProb[1].P[168]=0.000113675;
		pitchIntProb[0].P[169]=4.43597e-05;	pitchIntProb[1].P[169]=5.68376e-05;
		pitchIntProb[0].P[170]=4.43597e-05;	pitchIntProb[1].P[170]=0.000113675;
		pitchIntProb[0].P[171]=4.43597e-05;	pitchIntProb[1].P[171]=0.000113675;
		pitchIntProb[0].P[172]=4.43597e-05;	pitchIntProb[1].P[172]=5.68376e-05;
		pitchIntProb[0].P[173]=4.43597e-05;	pitchIntProb[1].P[173]=5.68376e-05;
		pitchIntProb[0].P[174]=4.43597e-05;	pitchIntProb[1].P[174]=0.000170513;
		pitchIntProb[0].P[175]=4.43597e-05;	pitchIntProb[1].P[175]=5.68376e-05;
		pitchIntProb[0].P[176]=4.43597e-05;	pitchIntProb[1].P[176]=5.68376e-05;
		pitchIntProb[0].P[177]=4.43597e-05;	pitchIntProb[1].P[177]=5.68376e-05;
		pitchIntProb[0].P[178]=4.43597e-05;	pitchIntProb[1].P[178]=5.68376e-05;
		pitchIntProb[0].P[179]=4.43597e-05;	pitchIntProb[1].P[179]=5.68376e-05;
		pitchIntProb[0].P[180]=4.43597e-05;	pitchIntProb[1].P[180]=0.000113675;
		pitchIntProb[0].P[181]=4.43597e-05;	pitchIntProb[1].P[181]=0.000113675;
		pitchIntProb[0].P[182]=4.43597e-05;	pitchIntProb[1].P[182]=5.68376e-05;
		pitchIntProb[0].P[183]=4.43597e-05;	pitchIntProb[1].P[183]=5.68376e-05;
		pitchIntProb[0].P[184]=4.43597e-05;	pitchIntProb[1].P[184]=5.68376e-05;
		pitchIntProb[0].P[185]=4.43597e-05;	pitchIntProb[1].P[185]=5.68376e-05;
		pitchIntProb[0].P[186]=4.43597e-05;	pitchIntProb[1].P[186]=5.68376e-05;
		pitchIntProb[0].P[187]=4.43597e-05;	pitchIntProb[1].P[187]=5.68376e-05;
		pitchIntProb[0].P[188]=4.43597e-05;	pitchIntProb[1].P[188]=5.68376e-05;
		pitchIntProb[0].P[189]=4.43597e-05;	pitchIntProb[1].P[189]=5.68376e-05;
		pitchIntProb[0].P[190]=4.43597e-05;	pitchIntProb[1].P[190]=5.68376e-05;
		pitchIntProb[0].P[191]=4.43597e-05;	pitchIntProb[1].P[191]=5.68376e-05;
		pitchIntProb[0].P[192]=4.43597e-05;	pitchIntProb[1].P[192]=5.68376e-05;
		pitchIntProb[0].P[193]=4.43597e-05;	pitchIntProb[1].P[193]=5.68376e-05;
		pitchIntProb[0].P[194]=4.43597e-05;	pitchIntProb[1].P[194]=5.68376e-05;
		pitchIntProb[0].P[195]=4.43597e-05;	pitchIntProb[1].P[195]=5.68376e-05;
		pitchIntProb[0].P[196]=4.43597e-05;	pitchIntProb[1].P[196]=5.68376e-05;
		pitchIntProb[0].P[197]=4.43597e-05;	pitchIntProb[1].P[197]=5.68376e-05;
		pitchIntProb[0].P[198]=4.43597e-05;	pitchIntProb[1].P[198]=5.68376e-05;
		pitchIntProb[0].P[199]=4.43597e-05;	pitchIntProb[1].P[199]=5.68376e-05;
		pitchIntProb[0].P[200]=4.43597e-05;	pitchIntProb[1].P[200]=5.68376e-05;
		pitchIntProb[0].P[201]=4.43597e-05;	pitchIntProb[1].P[201]=5.68376e-05;
		pitchIntProb[0].P[202]=4.43597e-05;	pitchIntProb[1].P[202]=5.68376e-05;
		pitchIntProb[0].P[203]=4.43597e-05;	pitchIntProb[1].P[203]=5.68376e-05;
		pitchIntProb[0].P[204]=4.43597e-05;	pitchIntProb[1].P[204]=5.68376e-05;
		pitchIntProb[0].P[205]=4.43597e-05;	pitchIntProb[1].P[205]=5.68376e-05;
		pitchIntProb[0].P[206]=4.43597e-05;	pitchIntProb[1].P[206]=5.68376e-05;
		pitchIntProb[0].P[207]=4.43597e-05;	pitchIntProb[1].P[207]=5.68376e-05;
		pitchIntProb[0].P[208]=4.43597e-05;	pitchIntProb[1].P[208]=5.68376e-05;
		pitchIntProb[0].P[209]=4.43597e-05;	pitchIntProb[1].P[209]=5.68376e-05;
		pitchIntProb[0].P[210]=4.43597e-05;	pitchIntProb[1].P[210]=5.68376e-05;
		pitchIntProb[0].P[211]=4.43597e-05;	pitchIntProb[1].P[211]=5.68376e-05;
		pitchIntProb[0].P[212]=4.43597e-05;	pitchIntProb[1].P[212]=5.68376e-05;
		pitchIntProb[0].P[213]=4.43597e-05;	pitchIntProb[1].P[213]=5.68376e-05;
		pitchIntProb[0].P[214]=4.43597e-05;	pitchIntProb[1].P[214]=5.68376e-05;
		pitchIntProb[0].P[215]=4.43597e-05;	pitchIntProb[1].P[215]=5.68376e-05;
		pitchIntProb[0].P[216]=4.43597e-05;	pitchIntProb[1].P[216]=5.68376e-05;
		pitchIntProb[0].P[217]=4.43597e-05;	pitchIntProb[1].P[217]=5.68376e-05;
		pitchIntProb[0].P[218]=4.43597e-05;	pitchIntProb[1].P[218]=5.68376e-05;
		pitchIntProb[0].P[219]=4.43597e-05;	pitchIntProb[1].P[219]=5.68376e-05;
		pitchIntProb[0].P[220]=4.43597e-05;	pitchIntProb[1].P[220]=5.68376e-05;
		pitchIntProb[0].P[221]=4.43597e-05;	pitchIntProb[1].P[221]=5.68376e-05;
		pitchIntProb[0].P[222]=4.43597e-05;	pitchIntProb[1].P[222]=5.68376e-05;
		pitchIntProb[0].P[223]=4.43597e-05;	pitchIntProb[1].P[223]=5.68376e-05;
		pitchIntProb[0].P[224]=4.43597e-05;	pitchIntProb[1].P[224]=5.68376e-05;
		pitchIntProb[0].P[225]=4.43597e-05;	pitchIntProb[1].P[225]=5.68376e-05;
		pitchIntProb[0].P[226]=4.43597e-05;	pitchIntProb[1].P[226]=5.68376e-05;
		pitchIntProb[0].P[227]=4.43597e-05;	pitchIntProb[1].P[227]=5.68376e-05;
		pitchIntProb[0].P[228]=4.43597e-05;	pitchIntProb[1].P[228]=5.68376e-05;
		pitchIntProb[0].P[229]=4.43597e-05;	pitchIntProb[1].P[229]=5.68376e-05;
		pitchIntProb[0].P[230]=4.43597e-05;	pitchIntProb[1].P[230]=5.68376e-05;
		pitchIntProb[0].P[231]=4.43597e-05;	pitchIntProb[1].P[231]=5.68376e-05;
		pitchIntProb[0].P[232]=4.43597e-05;	pitchIntProb[1].P[232]=5.68376e-05;
		pitchIntProb[0].P[233]=4.43597e-05;	pitchIntProb[1].P[233]=5.68376e-05;
		pitchIntProb[0].P[234]=4.43597e-05;	pitchIntProb[1].P[234]=5.68376e-05;
		pitchIntProb[0].P[235]=4.43597e-05;	pitchIntProb[1].P[235]=5.68376e-05;
		pitchIntProb[0].P[236]=4.43597e-05;	pitchIntProb[1].P[236]=5.68376e-05;
		pitchIntProb[0].P[237]=4.43597e-05;	pitchIntProb[1].P[237]=5.68376e-05;
		pitchIntProb[0].P[238]=4.43597e-05;	pitchIntProb[1].P[238]=5.68376e-05;
		pitchIntProb[0].P[239]=4.43597e-05;	pitchIntProb[1].P[239]=5.68376e-05;
		pitchIntProb[0].P[240]=4.43597e-05;	pitchIntProb[1].P[240]=5.68376e-05;
		pitchIntProb[0].P[241]=4.43597e-05;	pitchIntProb[1].P[241]=5.68376e-05;
		pitchIntProb[0].P[242]=4.43597e-05;	pitchIntProb[1].P[242]=5.68376e-05;
		pitchIntProb[0].P[243]=4.43597e-05;	pitchIntProb[1].P[243]=5.68376e-05;
		pitchIntProb[0].P[244]=4.43597e-05;	pitchIntProb[1].P[244]=5.68376e-05;
		pitchIntProb[0].P[245]=4.43597e-05;	pitchIntProb[1].P[245]=5.68376e-05;
		pitchIntProb[0].P[246]=4.43597e-05;	pitchIntProb[1].P[246]=5.68376e-05;
		pitchIntProb[0].P[247]=4.43597e-05;	pitchIntProb[1].P[247]=5.68376e-05;
		pitchIntProb[0].P[248]=4.43597e-05;	pitchIntProb[1].P[248]=5.68376e-05;
		pitchIntProb[0].P[249]=4.43597e-05;	pitchIntProb[1].P[249]=5.68376e-05;
		pitchIntProb[0].P[250]=4.43597e-05;	pitchIntProb[1].P[250]=5.68376e-05;
		pitchIntProb[0].P[251]=4.43597e-05;	pitchIntProb[1].P[251]=5.68376e-05;
		pitchIntProb[0].P[252]=4.43597e-05;	pitchIntProb[1].P[252]=5.68376e-05;
		pitchIntProb[0].P[253]=4.43597e-05;	pitchIntProb[1].P[253]=5.68376e-05;
		pitchIntProb[0].P[254]=4.43597e-05;	pitchIntProb[1].P[254]=5.68376e-05;
		pitchIntProb[0].P[255]=4.43597e-05;	pitchIntProb[1].P[255]=5.68376e-05;

		pitchIntProb[0].Normalize();
		pitchIntProb[1].Normalize();

//////Init tempo model
		sigma_t=0.02;
		lambda=0.0101;
		minSecPerQN=0.3;//BPM=200
		maxSeqPerQN=1.5;//BPM=40
		numTempoState=50;
		truncatedWidth=6;
		double sigmaV=1.;

		double eps=log(maxSeqPerQN/minSecPerQN)/numTempoState;
		for(int i=0;i<numTempoState;i+=1){
			secPerQN.push_back(minSecPerQN*exp(i*eps));
		}//endfor i

		tempoTrProb.resize(numTempoState);
		for(int i=0;i<numTempoState;i+=1){
			tempoTrProb[i].P.resize(numTempoState);

			for(int j=0;j<numTempoState;j+=1){
				tempoTrProb[i].P[j]=exp(-0.5*pow((i-j)/sigmaV,2.));
			}//endfor j
			tempoTrProb[i].Normalize();
		}//endfor i

		if(numTempoState-1>=truncatedWidth){
			outerLP=tempoTrProb[0].LP[truncatedWidth]-10;//ln(0.001)=-6.90775527898
		}else{//
			outerLP=tempoTrProb[0].LP[numTempoState-1]-10;//ln(0.001)=-6.90775527898
		}//endif

		tempoTrIniProb.P.resize(numTempoState);
		for(int i=0;i<numTempoState;i+=1){
			tempoTrIniProb.P[i]=exp(-0.5*pow((i-numTempoState/2)/(3*sigmaV),2.));
		}//endfor i
		tempoTrIniProb.Normalize();

		fac_sigma_p=-0.5*log(2*M_PI)-log(sigma_p);
		fac_sigma_p_ini=-0.5*log(2*M_PI)-log(sigma_p_ini);
		fac_sigma_t=-0.5*log(2*M_PI)-log(sigma_t);
		fac_lambda=-log(lambda);

if(printOn){cout<<"###Init END###"<<endl;}
	}//end Init

	void ReadData_Transcr(string filename){
		data.ReadFile(filename);
		TPQN=TPQN_;
	}//end ReadData_Transcr

	double OntimeLP(int nvID,int tempoID,double ioi){
		if(nvID>=numNVStates){
			return -1E100;
		}else{
			if(nvID%2==0){//short (chordal) IOI
				return fac_lambda-ioi/lambda;
			}else{//long (non-chordal) IOI
				return fac_sigma_t-0.5*pow((ioi-nv[nvID/2]*secPerQN[tempoID]/double(TPQN))/sigma_t,2.);
			}//endif
		}//endif
	}//end OntimeLP

	double PitchHandTrLP(int s,int p_pre,int p_cur,int HPPL,int HPPR){//HPP=handPartPreference
		if(s==0){
			return pitchIntProb[0].LP[p_cur-p_pre+128]+((HPPL>0)? -0.0202027:-0.693147)+((HPPR>0)? -3.912023:-0.693147);
		}else if(s==1){
			return pitchIntProb[1].LP[p_cur-p_pre+128]+((HPPR>0)? -0.0202027:-0.693147)+((HPPL>0)? -3.912023:-0.693147);
		}//endif
		return -1E100;
	}//end PitchTrLP

	double PitchTrIniLP(int s,int p){
		if(s==0){//left-hand
			return fac_sigma_p_ini-0.5*pow((double(p)-50)/sigma_p_ini,2.);
		}else{//right-hand
			return fac_sigma_p_ini-0.5*pow((double(p)-74)/sigma_p_ini,2.);
		}//endif
	}//end PitchTrIniLP

	double ExtTrLP(int nvID_pre,int nvID_cur){
		if(nvID_cur>=numNVStates){
			return -1E100;
		}else if(nvID_pre>=numNVStates){
			return trIniProb.LP[nvID_cur/2]+stateInProb[nvID_cur/2].LP[nvID_cur%2];
		}else{
			if(nvID_pre%2==0){//if same chord
				if(nvID_pre/2==nvID_cur/2){
					return stateStayProb[nvID_cur/2].LP[nvID_cur%2];
				}else{
					return -1E100;
				}//endif
			}else{//if new chord
				return trProb[nvID_pre/2].LP[nvID_cur/2]+stateInProb[nvID_cur/2].LP[nvID_cur%2];
			}//endif
		}//endif
	}//end ExtTrLP

	int IndexUnifier(int i_s,int i_h,int i_rL,int i_rR,int i_v){
		return i_s+2*(i_h+Nh*(i_rL+(numNVStates+1)*(i_rR+(numNVStates+1)*(i_v))));
	}//end IndexUnifier

	void Viterbi(){
if(printOn){cout<<"###Viterbi###"<<endl;}

/*
  i_s=0,1
  i_h=0,...,Nh-1
  i_rL=0,...,numNoteValue-1,INI
  i_rR=0,...,numNoteValue-1,INI
  i_v=0,...,numTempoState-1
  i=i_s+2*(i_h+Nh*(i_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(i_v))));
  i_s=i%2;
  i_h=(i/2)%Nh;
  i_rL=((i/2)/Nh)%(numNoteValue+1);
  i_rR=(((i/2)/Nh)/(numNoteValue+1))%(numNoteValue+1);
  i_v=(((i/2)/Nh)/(numNoteValue+1))/(numNoteValue+1);
  numAll=2*Nh*(numNoteValue+1)*(numNoteValue+1)*numTempoState;
*/
		vector<vector<int> > indexSplitter;//indexSplitter[i][0,1,2,3,4]=i_s,i_h,i_rL,i_rR,i_v
		vector<int> vi(5);
		for(int i_v=0;i_v<numTempoState;i_v+=1)
		for(int i_rR=0;i_rR<=numNVStates;i_rR+=1)
		for(int i_rL=0;i_rL<=numNVStates;i_rL+=1)
		for(int i_h=0;i_h<Nh;i_h+=1)
		for(int i_s=0;i_s<2;i_s+=1){
			vi[0]=i_s;
			vi[1]=i_h;
			vi[2]=i_rL;
			vi[3]=i_rR;
			vi[4]=i_v;
			indexSplitter.push_back(vi);
		}//endfor i_s,i_h,i_rL,i_rR,i_v

		int numAll=2*Nh*(numNVStates+1)*(numNVStates+1)*numTempoState;

		vector<double> ontimes;
		vector<int> pitches;
		for(int n=0;n<data.evts.size();n+=1){
			ontimes.push_back(data.evts[n].ontime);
			pitches.push_back(SitchToPitch(data.evts[n].sitch));
		}//endfor n
		pitches[pitches.size()-1]=pitches[pitches.size()-2];//Remark: the pitch of the last note is not defined

		int handPartPreference[pitches.size()][2];//HandPartPreference[m][0]=1 if m-th note is likely to be in the right-hand-part
		int dp_c=14;
		for(int n=0;n<pitches.size();n+=1){
			handPartPreference[n][0]=0;
			handPartPreference[n][1]=0;
			int p_max=pitches[n];
			int p_min=pitches[n];
			for(int m=0;m<pitches.size();m+=1){
				if(data.evts[m].offtime < data.evts[n].ontime){continue;}
				if(data.evts[m].ontime  > data.evts[n].offtime){break;}
				if(pitches[m]>p_max){p_max=pitches[m];}
				if(pitches[m]<p_min){p_min=pitches[m];}
			}//endfor m
			if(pitches[n]<p_max-dp_c){handPartPreference[n][0]=1;}//likely to be in the left-hand-part
			if(pitches[n]>p_min+dp_c){handPartPreference[n][1]=1;}//likely to be in the right-hand-part
		}//endfor n

		vector<double> LP;
		vector<vector<int> > amaxHist;
		vector<int> amax;
		amax.resize(numAll);
		double logP;

		LP.assign(numAll,-1E100);
		//Initial probability
		for(int i_s=0;i_s<2;i_s+=1){
			for(int i_v=0;i_v<numTempoState;i_v+=1){
				int i=IndexUnifier(i_s,0,numNVStates,numNVStates,i_v);
				LP[i]=-0.693147+tempoTrIniProb.LP[i_v]+PitchTrIniLP(i_s,pitches[0]);//ln(0.5)=-0.693147
			}//endfor i_v
		}//endfor i_s


		for(int n=1;n<ontimes.size();n+=1){
cout<<"Now Viterbi "<<(n+1)<<"/"<<ontimes.size()<<endl;

			vector<double> preLP(LP);
			LP.assign(numAll,-1E100);
			int i_s,i_h,i_rL,i_rR,i_v;
			for(int i=0;i<numAll;i+=1){//j->i
				int j;
/*
int				ii_s=i%2;
int				ii_h=(i/2)%Nh;
int				ii_rL=((i/2)/Nh)%(numNVStates+1);
int				ii_rR=(((i/2)/Nh)/(numNVStates+1))%(numNVStates+1);
int				ii_v=(((i/2)/Nh)/(numNVStates+1))/(numNVStates+1);
*/
				i_s=indexSplitter[i][0];
				i_h=indexSplitter[i][1];
				i_rL=indexSplitter[i][2];
				i_rR=indexSplitter[i][3];
				i_v=indexSplitter[i][4];

				if(i_s==0){//left-hand (j_rR=i_rR)

					if(i_h==0){
						//j_s=1 (i_h=0) {j_h,j_rL,j_v}
//						j=1+2*(0+Nh*(i_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(i_v))));
						j=IndexUnifier(1,0,i_rL,i_rR,i_v);

						if(n==1){
							LP[i]=preLP[j]
							+ExtTrLP(i_rL,i_rL)+tempoTrProb[i_v].LP[i_v]
							+PitchTrIniLP(i_s,pitches[n])
							+OntimeLP(i_rL,i_v,ontimes[n]-ontimes[0]);
						}else{//n>1
							LP[i]=preLP[j]
							+ExtTrLP(i_rL,i_rL)+tempoTrProb[i_v].LP[i_v]
							+PitchHandTrLP(i_s,pitches[n-2],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
						//+PitchTrLP(pitches[n-2],pitches[n])
							+OntimeLP(i_rL,i_v,ontimes[n]-ontimes[n-2]);
						}//endif
						amax[i]=j;

						for(int j_h=0;j_h<Nh;j_h+=1){
							if(n-2-j_h<-1){continue;}//n-1-(j_h+1)=n-2-j_h

							for(int j_rL=0;j_rL<=numNVStates;j_rL+=1){

								for(int j_v=i_v-truncatedWidth;j_v<=i_v+truncatedWidth;j_v+=1){
									if(j_v<0 || j_v>=numTempoState){continue;}

//									j=1+2*(j_h+Nh*(j_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(j_v))));
									j=IndexUnifier(1,j_h,j_rL,i_rR,j_v);
									if(n-2-j_h==-1){//initial condition
										logP=preLP[j]
										+ExtTrLP(j_rL,i_rL)+tempoTrProb[j_v].LP[i_v]
										+PitchTrIniLP(i_s,pitches[n])
										+OntimeLP(i_rL,i_v,ontimes[n]-ontimes[0]);
									}else{//n-2-j_h>=0
										logP=preLP[j]
										+ExtTrLP(j_rL,i_rL)+tempoTrProb[j_v].LP[i_v]
										+PitchHandTrLP(i_s,pitches[n-2-j_h],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
										+OntimeLP(i_rL,i_v,ontimes[n]-ontimes[n-2-j_h]);
									}//endif
									if(logP>LP[i]){LP[i]=logP; amax[i]=j;}

								}//endfor j_v
							}//endfor j_rL
						}//endfor j_h

					}else{//i_h>0

						//j_s=0 (j_h=i_h-1,i_h>0) {j_rL,j_v}
//						j=0+2*(i_h-1+Nh*(i_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(i_v))));
						j=IndexUnifier(i_s,i_h-1,i_rL,i_rR,i_v);
						LP[i]=preLP[j]
						+ExtTrLP(i_rL,i_rL)+tempoTrProb[i_v].LP[i_v]
						+PitchHandTrLP(i_s,pitches[n-1],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
						+OntimeLP(i_rL,i_v,ontimes[n]-ontimes[n-1]);
						amax[i]=j;
						for(int j_rL=0;j_rL<=numNVStates;j_rL+=1){
							for(int j_v=i_v-truncatedWidth;j_v<=i_v+truncatedWidth;j_v+=1){
								if(j_v<0 || j_v>=numTempoState){continue;}
//								j=0+2*(i_h-1+Nh*(j_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(j_v))));
								j=IndexUnifier(i_s,i_h-1,j_rL,i_rR,j_v);
								logP=preLP[j]
								+ExtTrLP(j_rL,i_rL)+tempoTrProb[j_v].LP[i_v]
								+PitchHandTrLP(i_s,pitches[n-1],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
								+OntimeLP(i_rL,i_v,ontimes[n]-ontimes[n-1]);
								if(logP>LP[i]){LP[i]=logP; amax[i]=j;}
							}//endfor j_v
						}//endfor j_rL

					}//endif

				}else if(i_s==1){//right-hand (j_rL=i_rL)

					if(i_h==0){
						//j_s=0 {j_h,j_rR,j_v}
	//					j=0+2*(0+Nh*(i_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(i_v))));
						j=IndexUnifier(0,0,i_rL,i_rR,i_v);
						if(n==1){
							LP[i]=preLP[j]
							+ExtTrLP(i_rR,i_rR)+tempoTrProb[i_v].LP[i_v]
							+PitchTrIniLP(i_s,pitches[n])
							+OntimeLP(i_rR,i_v,ontimes[n]-ontimes[0]);
						}else{//n>1
							LP[i]=preLP[j]
							+ExtTrLP(i_rR,i_rR)+tempoTrProb[i_v].LP[i_v]
							+PitchHandTrLP(i_s,pitches[n-2],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
							+OntimeLP(i_rR,i_v,ontimes[n]-ontimes[n-2]);
						}//endif
						amax[i]=j;

						for(int j_h=0;j_h<Nh;j_h+=1){
							if(n-2-j_h<-1){continue;}//n-1-(j_h+1)=n-2-j_h

							for(int j_rR=0;j_rR<=numNVStates;j_rR+=1){
								for(int j_v=i_v-truncatedWidth;j_v<=i_v+truncatedWidth;j_v+=1){
									if(j_v<0 || j_v>=numTempoState){continue;}
		//							j=0+2*(j_h+Nh*(i_rL+(numNoteValue+1)*(j_rR+(numNoteValue+1)*(j_v))));
									j=IndexUnifier(0,j_h,i_rL,j_rR,j_v);
									if(n-2-j_h==-1){//initial condition
										logP=preLP[j]
										+ExtTrLP(j_rR,i_rR)+tempoTrProb[j_v].LP[i_v]
										+PitchTrIniLP(i_s,pitches[n])
										+OntimeLP(i_rR,i_v,ontimes[n]-ontimes[0]);
									}else{//n-2-j_h>=0
										logP=preLP[j]
										+ExtTrLP(j_rR,i_rR)+tempoTrProb[j_v].LP[i_v]
										+PitchHandTrLP(i_s,pitches[n-2-j_h],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
										+OntimeLP(i_rR,i_v,ontimes[n]-ontimes[n-2-j_h]);
									}//endif
									if(logP>LP[i]){LP[i]=logP; amax[i]=j;}
								}//endfor j_v
							}//endfor j_rR
						}//endfor j_h

					}else{//i_h>0

						//j_s=1 (j_h=i_h-1,i_h>0) {j_rR,j_v}
//						j=1+2*(i_h-1+Nh*(i_rL+(numNoteValue+1)*(i_rR+(numNoteValue+1)*(i_v))));
						j=IndexUnifier(i_s,i_h-1,i_rL,i_rR,i_v);
						LP[i]=preLP[j]
						+ExtTrLP(i_rR,i_rR)+tempoTrProb[i_v].LP[i_v]
						+PitchHandTrLP(i_s,pitches[n-1],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
						+OntimeLP(i_rR,i_v,ontimes[n]-ontimes[n-1]);
						amax[i]=j;
						for(int j_rR=0;j_rR<=numNVStates;j_rR+=1){
							for(int j_v=i_v-truncatedWidth;j_v<=i_v+truncatedWidth;j_v+=1){
								if(j_v<0 || j_v>=numTempoState){continue;}
//								j=1+2*(i_h-1+Nh*(i_rL+(numNoteValue+1)*(j_rR+(numNoteValue+1)*(j_v))));
								j=IndexUnifier(i_s,i_h-1,i_rL,j_rR,j_v);
								logP=preLP[j]
								+ExtTrLP(j_rR,i_rR)+tempoTrProb[j_v].LP[i_v]
								+PitchHandTrLP(i_s,pitches[n-1],pitches[n],handPartPreference[n][0],handPartPreference[n][1])
								+OntimeLP(i_rR,i_v,ontimes[n]-ontimes[n-1]);
								if(logP>LP[i]){LP[i]=logP; amax[i]=j;}
							}//endfor j_v
						}//endfor j_rR

					}//endif
				}//endif

			}//endfor i
			amaxHist.push_back(amax);
		}//endfor n

		vector<int> optimalPath;

		optimalPath.resize(pitches.size());
		double max=LP[0];
		optimalPath[pitches.size()-1]=0;
		for(int i=0;i<numAll;i+=1){
			if(LP[i]>max){
				max=LP[i];
				optimalPath[pitches.size()-1]=i;
			}//endif
		}//endfor i
		for(int n=pitches.size()-2;n>=0;n-=1){
			optimalPath[n]=amaxHist[n][optimalPath[n+1]];
		}//endfor n

		data.evts[0].stime=0;
		data.evts[0].chan=indexSplitter[optimalPath[0]][0];
		data.evts[0].dur=-1;
		for(int i_s=0;i_s<2;i_s+=1){
			int preStime=0;
			for(int n=1;n<pitches.size();n+=1){
				data.evts[n].dur=-1;
				if(indexSplitter[optimalPath[n]][0]==i_s){
					if(indexSplitter[optimalPath[n]][2+i_s]%2==1){
						preStime+=nv[indexSplitter[optimalPath[n]][2+i_s]/2];
					}//endif
					data.evts[n].stime=preStime;
					data.evts[n].chan=indexSplitter[optimalPath[n]][0];
				}//endif
			}//endfor n
		}//endfor i_s

if(printOn){cout<<"###Viterbi END###"<<endl;}
	}//end Viterbi


	void Print(){
		for(int n=0;n<data.evts.size();n+=1){
			TranscrEvt evt=data.evts[n];
cout<<evt.ontime<<"\t"<<evt.sitch<<"\t"<<evt.stime<<"\t"<<evt.dur<<endl;
		}//endfor n
	}//end Print

	void WriteFile(string filename){
		data.TPQN=TPQN_;
		data.WriteFile(filename);
	}//end WriteFile

};//endclass MergedOutputHMM


#endif // MERGEDOUTPUTHMM_HPP


