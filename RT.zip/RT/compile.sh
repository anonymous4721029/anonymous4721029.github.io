#! /bin/bash

g++ -O2 RT_NoteHMM.cpp -o RT_NoteHMM
g++ -O2 RT_MetricalHMM.cpp -o RT_MetricalHMM
g++ -O2 RT_MergedOutputHMM.cpp -o RT_MergedOutputHMM
g++ CompareTranscrMultiVoice_v160317.cpp -o CompareTranscrMultiVoice
g++ MIDIToTranscr.cpp -o MIDIToTranscr
