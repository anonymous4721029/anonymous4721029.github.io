#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include<algorithm>
#include"MergedOutputHMM_v161223.hpp"
using namespace std;

int main(int argc, char** argv){

  vector<int> v(100);
  vector<double> d(100);
  vector<string> s(100);
  stringstream ss;
  clock_t start, end;
  start = clock();

  if(argc!=3){cout<<"Error in usage! : $./RT_MergedOutputHMM data_transcr.txt result_transcr.txt"<<endl; return -1;}

  MergedOutputHMM hmm;
  hmm.ReadData_Transcr(argv[1]);
  hmm.Viterbi();
  hmm.WriteFile(argv[2]);

  end = clock(); cout<<argv[1]<<"\t"<<"Elapsed time : "<<((double)(end - start) / CLOCKS_PER_SEC)<<" sec"<<endl; start=end;

  return 0;
}//end main



